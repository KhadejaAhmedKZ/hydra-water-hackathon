#!/usr/bin/env bash
# Build the policy brief and adoption roadmap.
export PATH="$PATH:/c/Users/ASUS/AppData/Local/Programs/MiKTeX/miktex/bin/x64"
cd "$(dirname "$0")"
for f in policy_brief adoption_roadmap; do
  pdflatex -interaction=nonstopmode "$f.tex" > "$f.log" 2>&1 || true
  pdflatex -interaction=nonstopmode "$f.tex" >> "$f.log" 2>&1 || true
  echo "--- $f ---"
  grep -E "^!" "$f.log" | head -6 || true
  grep -E "Output written" "$f.log" | tail -1 || echo "  NO OUTPUT"
done
