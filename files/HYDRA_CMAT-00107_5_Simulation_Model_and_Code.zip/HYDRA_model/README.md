# HYDRA simulation model and reproducibility package

**Project:** Renewable-Powered Desalination: A Sustainable Alternative to Conventional Water Treatment Systems
**Team:** HYDRA (Abu Dhabi University), Registration CMAT-00107
**Event:** Khalifa University – UN Global Water Hackathon 2026, Theme 1: Water Security and Sustainable Desalination
**Contact:** Muhammet Yalkapov (team leader), 1095390@students.adu.ac.ae

This package contains the hourly simulation model behind the technical report, the
data it runs on, the saved results, and the scripts that turn those results into
every number, table and figure in the report, policy brief, roadmap and dashboard.

---

## Contents

| Folder | What it holds |
|---|---|
| `03_model/` | The model (`config.py`, `physics.py`, `fouling.py`, `simulate.py`), the experiment runner, the audit script, and cached input data in `data/` |
| `03_model/results/` | Saved outputs of experiments E1 to E8, used by every downstream script |
| `04_paper/` | Report source: `main.tex`, `references.bib`, and the generated `numbers.tex` and `param_table.tex` |
| `05_figures/` | The seven result figures (PNG and PDF) and the dashboard figure |
| `06_deliverables/` | Policy brief and roadmap sources, `dashboard.html` (the decision-support platform) and the logo |
| `02_literature/` | `VERIFICATION_LOG.md`: every cited number traced to its source |

## Requirements

- Python 3.8 or newer (tested on 3.8.10) with the packages in `requirements.txt`:
  `python -m pip install -r requirements.txt`
- Only to rebuild the PDFs: a LaTeX distribution with `pdflatex` and `bibtex`.
- The dashboard needs only a web browser. It loads its fonts from Google Fonts when online and falls back to system fonts offline.

## Quick check (under a minute)

```bash
cd 03_model
python verify_paper.py
```

This independently recomputes every load-bearing number in the report from the saved
results (86 checks) and confirms every referenced figure exists. It exits with code 0
when everything agrees.

## Full reproduction (about 55 minutes)

```bash
cd 03_model
python fetch_resource_data.py      # optional: re-download NASA POWER data (cached copies are in data/)
python run_experiments.py          # runs E1 to E8 and rewrites results/
python make_param_table.py         # parameter appendix and provenance census
python make_numbers.py             # 04_paper/numbers.tex, so no number is typed by hand
python make_figures.py             # all figures, from the saved results only
python verify_paper.py             # must exit 0
cd ../04_paper && bash build.sh    # pdflatex, bibtex, pdflatex x2
cd ../06_deliverables && bash build.sh
```

`run_experiments.py` holds a lock file, so a second concurrent run is refused.
`check_provenance.py` flags result files that are older than the parameters that produced them.

## Where each result comes from

| Experiment | Results file | Used for |
|---|---|---|
| E1 | `E1_seasonal.csv`, `E1_calibration.txt` | Benchmarks and seasonal fouling and energy (Fig. 1) |
| E2 | `E2_policies.csv` | Wear-ignored vs wear-counted dispatch and cost breakdown (Fig. 2) |
| E3 | `E3_design_space.csv` | Solar capacity, saturation and carbon price (Fig. 7) |
| E4 | `E4_cycle_frontier.csv` | Cycle-tolerance frontier and the 4,200-cycle break-even (Fig. 3) |
| E5 | `E5_frontier_2d.csv` | Frontier across biofouling index (Fig. 4) |
| E6 | `E6_tariff_frontier.csv` | Time-of-use tariff spread (Fig. 5) |
| E7 | `E7_cost_of_blindness.json` | How far a wear-blind model misjudges its own design |
| E8 | `E8_sensitivity.csv` | One-at-a-time sensitivity (Fig. 6) |

## Parameters and honesty about them

Every parameter in `config.py` carries a provenance tag: `LIT` (published literature),
`IND` (industry value), `DER` (derived), `ASM` (assumption of this study), `ENG`
(standard engineering value) or `DATA` (measured input). Of 52 parameters, 34 are
assumptions, 9 are standard engineering values and 5 come from the literature. The
report states its conclusions as functions of those assumptions. The decisive
parameter, permanent permeability loss per start/stop cycle in warm hypersaline
seawater, has not been measured; the report specifies the bench experiment that would
measure it.

## Data acknowledgement

Hourly irradiance, air temperature, wind and daily aerosol optical depth for 2023 at the
Al Taweelah site were obtained from the NASA Langley Research Center (LaRC) POWER Project
funded through the NASA Earth Science/Applied Science Program.
