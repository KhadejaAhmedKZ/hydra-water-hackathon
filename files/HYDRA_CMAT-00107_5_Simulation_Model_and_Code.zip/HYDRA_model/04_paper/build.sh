#!/usr/bin/env bash
# Full LaTeX build for the manuscript.
set -e
export PATH="$PATH:/c/Users/ASUS/AppData/Local/Programs/MiKTeX/miktex/bin/x64"
cd "$(dirname "$0")"
pdflatex -interaction=nonstopmode main.tex > build1.log 2>&1 || true
bibtex main > build_bib.log 2>&1 || true
pdflatex -interaction=nonstopmode main.tex > build2.log 2>&1 || true
pdflatex -interaction=nonstopmode main.tex > build3.log 2>&1 || true
echo "=== errors ==="
grep -E "^!" build3.log | head -20 || echo "  none"
echo "=== undefined references/citations ==="
grep -iE "undefined (control sequence|reference|citation)" build3.log | head -10 || echo "  none"
echo "=== bibtex ==="
grep -iE "error|warning|couldn" build_bib.log | head -10 || echo "  clean"
echo "=== result ==="
grep -E "Output written" build3.log | tail -1
