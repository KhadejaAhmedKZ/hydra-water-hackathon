"""
simulate.py — Hourly co-simulation of PV, RO dispatch, fouling and economics.

Simulates one representative SWRO train serving a FIXED water obligation at
the Al Taweelah site, under a choice of dispatch policy and plant design, and
returns the levelized cost of water together with the physical diagnostics
needed to explain it.

DESIGN VARIABLES
  ro_oversize   RO nameplate / mean water obligation. Oversizing is what BUYS
                flexibility: only a plant with spare capacity can concentrate
                production into sunlit hours. Conventional plants sit at ~1.09.
  pv_kWp        co-located PV capacity
  batt_kWh      battery energy storage
  tank_hours    product-water storage, expressed in hours of mean demand

The object of the study is the DIFFERENCE between policies that ignore
membrane degradation and policies that price it, because that difference is
exactly what the existing renewable-dispatch literature omits.

POLICIES
  baseload_grid   flat output, grid only, no PV            (counterfactual)
  pv_baseload     flat output, PV displaces grid           (current practice,
                                                            e.g. Al Taweelah)
  pv_flex_blind   RO follows PV, degradation ignored       (dispatch-literature
                                                            assumption)
  pv_flex_aware   RO follows PV, degradation PRICED        (this study)
"""

import math
import os

import numpy as np
import pandas as pd

import config as C
import physics as P
import fouling as F

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
HOURS_PER_YEAR = 8760


# ===========================================================================
# Resource and demand series
# ===========================================================================
def load_resource(year=2023):
    """Loads NASA POWER hourly resource data and builds the derived series."""
    hp = os.path.join(DATA_DIR, "taweelah_hourly_%d.csv" % year)
    ap = os.path.join(DATA_DIR, "taweelah_aod_%d.csv" % year)

    h = pd.read_csv(hp, index_col=0, parse_dates=True).head(HOURS_PER_YEAR).copy()

    ghi = np.nan_to_num(h["ALLSKY_SFC_SW_DWN"].to_numpy(dtype=float), nan=0.0)
    tair = pd.Series(h["T2M"].to_numpy(dtype=float)).interpolate(
        limit_direction="both").to_numpy()
    wind = pd.Series(h["WS10M"].to_numpy(dtype=float)).interpolate(
        limit_direction="both").to_numpy()

    doy = np.array([d.timetuple().tm_yday for d in h.index])
    tsea = P.sst_profile(doy)

    if os.path.exists(ap):
        aod = pd.read_csv(ap, index_col=0, parse_dates=True)["AOD_55"].to_numpy(
            dtype=float)[:366]
    else:
        aod = np.full(365, 0.545)
    soil_daily = P.soiling_loss(aod)
    soil_hourly = np.repeat(soil_daily, 24)[:len(ghi)]
    if len(soil_hourly) < len(ghi):
        soil_hourly = np.pad(soil_hourly, (0, len(ghi) - len(soil_hourly)), mode="edge")

    return dict(ghi=ghi, tair=tair, wind=wind, tsea=tsea, doy=doy,
                soiling=soil_hourly, index=h.index,
                aod_mean=float(np.nanmean(aod)))


def build_tariff(index, n):
    """Hourly electricity import price, USD/kWh.

    shape(t) = -1 in the solar-rich midday window, +1 in the evening peak,
    0 otherwise; price = base * (1 + spread * shape). With spread = 0 this
    reduces to today's flat UAE industrial tariff.
    """
    e = C.ECON
    base, spread = e["elec_price_usd_kWh"], e["tariff_spread"]
    lo0, lo1 = e["tariff_solar_hours"]
    hi0, hi1 = e["tariff_peak_hours"]

    local_hours = np.array([(t.hour + 4) % 24 for t in index[:n]])
    shape = np.zeros(n)
    shape[(local_hours >= lo0) & (local_hours < lo1)] = -1.0
    shape[(local_hours >= hi0) & (local_hours < hi1)] = +1.0
    return base * (1.0 + spread * shape)


def build_demand(doy, n):
    """Hourly water obligation, m3/h. INDEPENDENT of how the plant is built."""
    d = C.DEMAND
    base_h = C.DEMAND_M3_DAY / 24.0
    seasonal = 1.0 + d["summer_peak_amplitude"] * np.cos(
        2.0 * np.pi * (doy - d["peak_doy"]) / 365.25)
    hours = np.arange(n) % 24
    diurnal = 1.0 + d["diurnal_amplitude"] * np.sin(2.0 * np.pi * (hours - 6) / 24.0)
    return base_h * seasonal * diurnal


# ===========================================================================
# Dispatch policies
#   Each policy receives a context dict and returns a load fraction in [0,1]
#   relative to RO NAMEPLATE capacity.
# ===========================================================================
def policy_baseload_grid(ctx):
    """Flat output matched to demand. No PV. Conventional counterfactual."""
    return ctx["demand_frac"]


def policy_pv_baseload(ctx):
    """Flat output; PV merely displaces grid import when available.

    Current commercial practice: the solar plant reduces the electricity bill
    but the RO trains keep running at steady load.
    """
    return ctx["demand_frac"]


def policy_pv_flex_blind(ctx):
    """Follow PV as far as the operating envelope allows; ignore degradation.

    This is the behaviour assumed by dispatch models that treat the RO plant
    as a static power-to-water converter.
    """
    sec, cap_h = ctx["sec"], ctx["cap_h"]
    L_pv = float(np.clip(ctx["pv_kW"] / (sec * cap_h), 0.0, 1.0)) if sec > 0 else 0.0
    if L_pv < C.RO["load_min"]:
        return 0.0
    return min(L_pv, C.RO["load_max"])


def marginal_degradation_cost(load_fraction, T_sea, is_restart, lam_irr, dt_h=1.0):
    """USD cost of the irreversible fouling caused by one hour of operation at
    `load_fraction` (or of idling, if load_fraction == 0).

    This is the term the dispatch literature omits. It converts a physical
    degradation rate into money through the shadow price derived in
    fouling.degradation_shadow_price():

        cost = lambda_irr * dR_irreversible

    The rate laws are the same ones used in the state update, so policy and
    physics are consistent by construction.
    """
    f = C.FOULING
    if load_fraction > 0:
        rate = F.fouling_rate_operating(T_sea, load_fraction)
    else:
        rate = F.fouling_rate_idle(T_sea)
    dR = float(rate) * dt_h * f["irreversible_fraction"]
    if is_restart:
        dR += f["dRf_per_restart"] * f["irreversible_fraction_restart"]
    return lam_irr * dR


def policy_pv_flex_aware(ctx):
    """Follow PV, but price the membrane-life penalty of doing so.

    -----------------------------------------------------------------------
    DESIGN DECISION -- the core behavioural choice of the study.
    -----------------------------------------------------------------------
    For each candidate load fraction we evaluate the net hourly cost

        net(L) = energy_cost(L) + degradation_cost(L) - water_value(L)

    and select the minimum. `water_value` is required because water produced
    now and banked in the tank displaces production later; without it the
    policy would shut down whenever electricity is not free.

    The candidate set deliberately includes L = 0 so the policy can conclude
    that idling is WORSE than running -- which in the Gulf it frequently is,
    because stagnation fouls faster than part-load operation.
    """
    cap_h, sec, price = ctx["cap_h"], ctx["sec"], ctx["price"]
    pv_kW, lam, T_sea = ctx["pv_kW"], ctx["lam_irr"], ctx["T_sea"]
    was_running, water_value = ctx["was_running"], ctx["water_value"]
    exp_price = C.ECON["elec_export_usd_kWh"]

    candidates = [0.0] + list(np.linspace(C.RO["load_min"], C.RO["load_max"], 7))
    best_L, best_net = 0.0, float("inf")

    for L in candidates:
        running = L > 0.0
        is_restart = running and not was_running

        if running:
            water = L * cap_h
            power = sec * water
            from_pv = min(power, pv_kW)
            e_cost = (power - from_pv) * price - max(0.0, pv_kW - power) * exp_price
            w_val = water * water_value
        else:
            e_cost = -pv_kW * exp_price
            w_val = 0.0

        net = e_cost + marginal_degradation_cost(L, T_sea, is_restart, lam) - w_val
        if net < best_net:
            best_net, best_L = net, L

    return best_L


# ---------------------------------------------------------------------------
# Parameterised flexible policy — used for the CONTROLLED comparison
# ---------------------------------------------------------------------------
# The policies above differ in both objective AND foresight, which makes them
# unsuitable for isolating the effect of pricing degradation. The family below
# fixes that: a single dispatch STRUCTURE with two knobs.
#
#   pv_threshold  fraction of PV nameplate above which the plant prefers to
#                 concentrate production. This supplies the day-ahead
#                 foresight that a myopic hourly rule lacks, and is the same
#                 for both objectives.
#   deg_weight    weight on the marginal degradation cost.
#                   0.0 -> fouling-BLIND  (the dispatch-literature assumption)
#                   1.0 -> fouling-AWARE  (this study)
#
# Because the two cases share structure and foresight and differ ONLY in
# deg_weight, any difference in the chosen dispatch is attributable to the
# degradation term and nothing else.
def make_flex_policy(pv_threshold=0.25, deg_weight=1.0, aggression=1.0):
    """Returns a dispatch policy with day-ahead PV thresholding.

    aggression : 0.0 -> the deferral term is switched off entirely, so the
                        policy reduces to steady baseload operation
                 1.0 -> full deferral, i.e. maximal solar-following

    Including aggression = 0 is essential. If "do not flex at all" is the
    economically correct answer -- which in severe fouling conditions it is --
    then the policy family MUST be able to express it. A family that always
    defers measures the heuristic rather than the physics, and can report a
    degradation-aware policy as worse than baseload, which is incoherent for
    a policy that is supposed to be minimising true cost.
    """

    def _policy(ctx):
        cap_h, sec, price = ctx["cap_h"], ctx["sec"], ctx["price"]
        pv_kW, lam, T_sea = ctx["pv_kW"], ctx["lam_irr"], ctx["T_sea"]
        was_running, water_value = ctx["was_running"], ctx["water_value"]
        pv_nameplate = max(ctx["pv_nameplate"], 1e-9)
        exp_price = C.ECON["elec_export_usd_kWh"]

        # Day-ahead foresight: is this a "good" PV hour?
        pv_frac = pv_kW / pv_nameplate
        sunny = pv_frac >= pv_threshold

        # Tank-space opportunity cost. If the tank is nearly full and a good
        # PV window is expected, producing now forfeits the chance to absorb
        # cheap energy later. This is the term the myopic rule was missing.
        fill = ctx["tank"] / max(ctx["tank_cap"], 1e-9)
        defer_bonus = aggression * ctx["pv_expected_24h"] * fill

        candidates = [0.0] + list(np.linspace(C.RO["load_min"], C.RO["load_max"], 7))
        best_L, best_net = 0.0, float("inf")

        for L in candidates:
            running = L > 0.0
            is_restart = running and not was_running

            if running:
                water = L * cap_h
                power = sec * water
                from_pv = min(power, pv_kW)
                e_cost = ((power - from_pv) * price
                          - max(0.0, pv_kW - power) * exp_price)
                w_val = water * water_value
                # penalise producing into a full tank during a poor PV hour
                if not sunny:
                    w_val -= water * water_value * min(1.0, defer_bonus)
            else:
                e_cost = -pv_kW * exp_price
                w_val = 0.0

            d_cost = deg_weight * marginal_degradation_cost(
                L, T_sea, is_restart, lam)
            net = e_cost + d_cost - w_val
            if net < best_net:
                best_net, best_L = net, L

        return best_L

    return _policy


POLICIES = {
    "baseload_grid": policy_baseload_grid,
    "pv_baseload": policy_pv_baseload,
    "pv_flex_blind": policy_pv_flex_blind,
    "pv_flex_aware": policy_pv_flex_aware,
}
USES_PV = {"baseload_grid": False, "pv_baseload": True,
           "pv_flex_blind": True, "pv_flex_aware": True}


# ===========================================================================
# Core simulation
# ===========================================================================
def simulate(policy="pv_flex_aware", pv_kWp=0.0, batt_kWh=0.0, tank_hours=6.0,
             ro_oversize=None, years=3, resource=None):
    """Runs the hourly co-simulation. Returns a results dict."""
    if resource is None:
        resource = load_resource()
    if ro_oversize is None:
        ro_oversize = C.RO_OVERSIZE_DEFAULT

    ghi, tair, wind = resource["ghi"], resource["tair"], resource["wind"]
    tsea, doy, soil = resource["tsea"], resource["doy"], resource["soiling"]
    n_year = len(ghi)

    # ---- plant sizing -----------------------------------------------------
    ro_cap_m3_day = C.DEMAND_M3_DAY * ro_oversize
    cap_h = ro_cap_m3_day / 24.0
    demand = build_demand(doy, n_year)
    mean_dem_h = C.DEMAND_M3_DAY / 24.0

    # policy may be a registry name or a callable from make_flex_policy()
    if callable(policy):
        pol, pol_name, uses_pv = policy, getattr(policy, "label", "flex_custom"), True
    else:
        pol, pol_name, uses_pv = POLICIES[policy], policy, USES_PV[policy]

    pv_kWp_eff = pv_kWp if uses_pv else 0.0
    pv_series = (P.pv_output_kW(ghi, tair, pv_kWp_eff, soil, wind)
                 if pv_kWp_eff > 0 else np.zeros(n_year))

    # Forward-looking 24 h PV availability, normalised to its annual mean.
    # This is the day-ahead signal available to a real plant operator.
    if pv_kWp_eff > 0:
        kern = np.ones(24)
        fwd = np.convolve(np.concatenate([pv_series, pv_series[:24]]), kern,
                          mode="full")[23:23 + n_year]
        pv_exp_24 = fwd / max(fwd.mean(), 1e-9)
    else:
        pv_exp_24 = np.zeros(n_year)

    lam_irr, R_replace, C_mem_train = F.degradation_shadow_price(
        capacity_m3_day=ro_cap_m3_day)

    sec_ref = P.sec_total_kWh_m3(C.SEAWATER["salinity_g_L"],
                                 C.SEAWATER["sst_mean_C"],
                                 C.RO["recovery"], 0.0, 1.0)
    water_value = sec_ref * C.ECON["elec_price_usd_kWh"]

    tank_cap = tank_hours * mean_dem_h
    tank = 0.5 * tank_cap
    batt_cap = batt_kWh * C.STORAGE["batt_dod"]
    batt = 0.0
    eta_ow = math.sqrt(C.STORAGE["batt_eta_rt"])

    st = F.MembraneState()

    tot_water = tot_demand = tot_unmet = 0.0
    grid_kWh = pv_used_kWh = pv_export_kWh = pv_avail_kWh = 0.0
    e_cost = export_rev = 0.0
    n_hours_running = 0
    sec_weighted = 0.0
    cip_capped_hours = 0
    tariff = build_tariff(resource["index"], n_year)

    log_perm, log_load, log_pv = [], [], []

    for yr in range(years):
        st.new_year()
        for i in range(n_year):
            T_s = float(tsea[i])
            pv_kW = float(pv_series[i])
            dem = float(demand[i])
            price = float(tariff[i])
            pv_avail_kWh += pv_kW

            # SEC evaluated at current fouling state, full-load reference
            sec = float(P.sec_total_kWh_m3(C.SEAWATER["salinity_g_L"], T_s,
                                           C.RO["recovery"], st.R_total, 1.0))

            ctx = dict(pv_kW=pv_kW, sec=sec, cap_h=cap_h, price=price,
                       T_sea=T_s, demand_frac=min(1.0, dem / cap_h),
                       was_running=st.running_prev, lam_irr=lam_irr,
                       tank=tank, tank_cap=tank_cap, water_value=water_value,
                       pv_nameplate=pv_kWp_eff,
                       pv_expected_24h=float(pv_exp_24[i]))

            L = float(np.clip(pol(ctx), 0.0, 1.0))

            # ---- feasibility: the tank must not run dry ------------------
            deficit = dem - tank
            if deficit > 0:
                L = max(L, min(1.0, deficit / cap_h))
            # ---- and must not overflow -----------------------------------
            headroom = tank_cap - tank + dem
            if L * cap_h > headroom:
                L = max(0.0, headroom / cap_h)
            if 0.0 < L < C.RO["load_min"]:
                L = C.RO["load_min"] if L > 0.5 * C.RO["load_min"] else 0.0

            running = L > 0.0
            water = L * cap_h if running else 0.0

            # ---- energy sourcing, with part-load pump derating -----------
            if running:
                sec_now = float(P.sec_total_kWh_m3(
                    C.SEAWATER["salinity_g_L"], T_s, C.RO["recovery"],
                    st.R_total, L))
                power = sec_now * water
            else:
                sec_now, power = 0.0, 0.0

            from_pv = min(power, pv_kW)
            residual = power - from_pv
            surplus = pv_kW - from_pv

            if batt_cap > 0:
                if surplus > 0:
                    charge = min(surplus * eta_ow, batt_cap - batt)
                    batt += charge
                    surplus -= charge / eta_ow
                if residual > 0 and batt > 0:
                    draw = min(residual / eta_ow, batt)
                    batt -= draw
                    residual -= draw * eta_ow

            grid_kWh += residual
            pv_used_kWh += from_pv
            pv_export_kWh += max(0.0, surplus)
            e_cost += residual * price
            export_rev += max(0.0, surplus) * C.ECON["elec_export_usd_kWh"]

            # ---- water balance -------------------------------------------
            tank += water - dem
            if tank < 0:
                tot_unmet += -tank
                tank = 0.0
            tank = min(tank, tank_cap)
            tank *= (1.0 - C.STORAGE["tank_loss_per_day"] / 24.0)

            tot_water += water
            tot_demand += dem
            if running:
                n_hours_running += 1
                sec_weighted += sec_now * water

            if st.cip_this_year >= C.FOULING["cip_max_per_year"]:
                cip_capped_hours += 1

            st.step(1.0, T_s, running, max(L, 1e-6))

            if yr == years - 1 and i % 24 == 0:
                log_perm.append(st.perm_ratio(T_s))
                log_load.append(L)
                log_pv.append(pv_kW)

    # =====================================================================
    # Economics
    # =====================================================================
    econ = C.ECON
    n, r = econ["plant_life_years"], econ["discount_rate"]
    crf = r * (1 + r) ** n / ((1 + r) ** n - 1)

    pv_area = pv_kWp_eff / C.PV["eta_stc"] if pv_kWp_eff > 0 else 0.0

    capex = (ro_cap_m3_day * econ["ro_capex_usd_m3_day"]
             + pv_kWp_eff * econ["pv_capex_usd_kWp"]
             + batt_kWh * econ["batt_capex_usd_kWh"]
             + tank_cap * econ["tank_capex_usd_m3"])

    yrs = float(years)
    ann_water = tot_water / yrs
    ann_delivered = (tot_demand - tot_unmet) / yrs
    ann_elec_cost = e_cost / yrs
    ann_export_rev = export_rev / yrs
    # Membrane cost is annualised from CUMULATIVE IRREVERSIBLE DEGRADATION,
    # not from the integer replacement count. Counting discrete replacements
    # quantises the cost to multiples of 1/horizon per year, so over a 3-year
    # run a 1.5-year membrane life and a 2.4-year one both register exactly one
    # replacement and thus identical cost -- an artefact that masks the very
    # effect this study measures.
    repl_per_yr = st.replacements_per_year(yrs)
    ann_membrane = repl_per_yr * C_mem_train
    life_proj = st.projected_membrane_life_years(yrs)
    ann_cip = st.n_cip / yrs * C.FOULING["cip_cost_usd_per_train"]
    ann_pv_clean = pv_area * C.PV["clean_cost_usd_per_m2"] * (
        365.0 / C.PV["clean_interval_days"])
    ann_fixed = ann_water * econ["opex_fixed_usd_m3"]

    ann_opex = (ann_elec_cost - ann_export_rev + ann_membrane + ann_cip
                + ann_pv_clean + ann_fixed)

    # LCOW is charged against water actually DELIVERED to the utility, so that
    # designs which fail to meet the obligation are penalised rather than
    # rewarded for producing less.
    denom = ann_delivered if ann_delivered > 0 else float("nan")
    lcow = (crf * capex + ann_opex) / denom

    ann_grid = grid_kWh / yrs
    ann_pv_used = pv_used_kWh / yrs
    tot_e = ann_pv_used + ann_grid
    re_frac = ann_pv_used / tot_e if tot_e > 0 else 0.0
    sec_mean = sec_weighted / tot_water if tot_water > 0 else float("nan")

    return dict(
        policy=pol_name, pv_kWp=pv_kWp_eff, batt_kWh=batt_kWh,
        tank_hours=tank_hours, ro_oversize=ro_oversize,
        ro_cap_m3_day=ro_cap_m3_day, years=years,
        lcow_usd_m3=lcow,
        capex_usd=capex, crf=crf,
        ann_water_m3=ann_water, ann_delivered_m3=ann_delivered,
        ann_demand_m3=tot_demand / yrs,
        unmet_frac=tot_unmet / tot_demand if tot_demand > 0 else 0.0,
        sec_mean_kWh_m3=sec_mean,
        re_fraction=re_frac,
        ann_grid_kWh=ann_grid, ann_pv_used_kWh=ann_pv_used,
        ann_pv_export_kWh=pv_export_kWh / yrs,
        pv_curtail_frac=(pv_export_kWh / pv_avail_kWh) if pv_avail_kWh > 0 else 0.0,
        cost_elec=ann_elec_cost / denom,
        cost_membrane=ann_membrane / denom,
        cost_cip=ann_cip / denom,
        cost_capital=crf * capex / denom,
        cost_fixed=ann_fixed / denom,
        cost_pv_clean=ann_pv_clean / denom,
        rev_export=ann_export_rev / denom,
        n_cip_per_yr=st.n_cip / yrs,
        n_replace_per_yr=repl_per_yr,
        n_replace_events_per_yr=st.n_replace / yrs,
        n_restart_per_yr=st.n_restart / yrs,
        membrane_life_yr=life_proj,
        membrane_life_observed_yr=st.mean_membrane_life_years(),
        capacity_factor=n_hours_running / (n_year * yrs),
        cip_capped_frac=cip_capped_hours / (n_year * yrs),
        co2_t_yr=ann_grid * econ["grid_co2_kg_kWh"] / 1000.0,
        log_perm=log_perm, log_load=log_load, log_pv=log_pv,
    )


def summarize(res):
    return ("%-14s ovr=%.2f PV=%6.0f kWp batt=%6.0f tank=%4.1fh | "
            "LCOW %6.3f | SEC %5.2f | RE %5.1f%% | memlife %4.2f yr | "
            "CIP/yr %4.1f | restart/yr %5.0f | CF %4.2f | unmet %4.2f%%"
            % (res["policy"], res["ro_oversize"], res["pv_kWp"], res["batt_kWh"],
               res["tank_hours"], res["lcow_usd_m3"], res["sec_mean_kWh_m3"],
               100 * res["re_fraction"], res["membrane_life_yr"],
               res["n_cip_per_yr"], res["n_restart_per_yr"],
               res["capacity_factor"], 100 * res["unmet_frac"]))


if __name__ == "__main__":
    rs = load_resource()
    print("Resource: %d h, mean AOD %.3f, GHI %.0f kWh/m2/yr, Tsea %.1f-%.1f C"
          % (len(rs["ghi"]), rs["aod_mean"], rs["ghi"].sum() / 1000,
             rs["tsea"].min(), rs["tsea"].max()))
    print("Water obligation: %.0f m3/day\n" % C.DEMAND_M3_DAY)

    # PV sized for a meaningful renewable fraction. Energy need is roughly
    # DEMAND * SEC; at ~2000 kWh/m2/yr a kWp yields ~1700 kWh/yr AC.
    e_need = C.DEMAND_M3_DAY * 365 * 3.9
    pv_100 = e_need / 1700.0
    print("PV for ~100%% annual energy parity: %.0f kWp" % pv_100)
    print("Al Taweelah installed PV scaled to this train: %.0f kWp (%.0f%% parity)\n"
          % (C.SITE["pv_installed_MWp"] * 1000 * C.TRAIN_FRACTION,
             100 * C.SITE["pv_installed_MWp"] * 1000 * C.TRAIN_FRACTION / pv_100))

    print("--- conventional design (oversize 1.09, no flexibility headroom) ---")
    for pol in POLICIES:
        print(summarize(simulate(pol, pv_kWp=0.6 * pv_100, tank_hours=6.0,
                                 ro_oversize=1.09, years=3, resource=rs)))

    print("\n--- flexibility-enabled design (oversize 1.60, 12 h tank) ---")
    for pol in POLICIES:
        print(summarize(simulate(pol, pv_kWp=0.6 * pv_100, tank_hours=12.0,
                                 ro_oversize=1.60, years=3, resource=rs)))
