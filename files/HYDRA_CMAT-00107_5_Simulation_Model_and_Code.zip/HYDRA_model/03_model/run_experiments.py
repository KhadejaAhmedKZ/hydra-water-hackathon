"""
run_experiments.py — Generates every numerical result reported in the paper.

CENTRAL QUANTITY
  N_tol : the number of start/stop cycles a membrane must tolerate before its
          irreversible-fouling budget is exhausted,

              N_tol = R_replace / (dRf_per_restart * f_irr_restart)

          This converts an abstract model coefficient into a quantity that can
          be MEASURED on a bench rig: cycle a seawater element daily and record
          the permeability not recovered by cleaning. Reporting the frontier in
          N_tol makes the paper's conclusion falsifiable.

EXPERIMENTS
  E1  Calibration anchors + Gulf seasonal energy/fouling tension
  E2  Controlled policy comparison (same structure and foresight,
      degradation weight 0 vs 1)
  E3  Design-space sweep: PV capacity x RO oversize
  E4  Cycle-tolerance frontier: locate N_tol at which flexible
      renewable-following dispatch becomes economic
  E5  Two-dimensional frontier: N_tol x biofouling severity
  E6  Tariff-spread frontier: N_tol x time-of-use spread
  E7  Cost of designing with a degradation-blind model
  E8  One-at-a-time sensitivity over all flagged parameters

Results are written to results/*.csv so analysis and figures never require
re-simulation.
"""

import contextlib
import itertools
import json
import os
import sys
import time

import numpy as np
import pandas as pd

import config as C
import physics as P
import fouling as F
import simulate as S

RESDIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
os.makedirs(RESDIR, exist_ok=True)

LOCKFILE = os.path.join(RESDIR, ".run.lock")


def acquire_lock():
    """Refuse to start if another run is already writing to results/.

    This exists because of a real incident: six concurrent runs of this script
    accumulated in the background, each writing to results/ with a different
    code version and a different parameter grid. The result was a directory of
    mixed-provenance CSVs that were indistinguishable from valid ones by
    content alone, and two rounds of wrong numbers reached the manuscript
    before an audit caught them.

    Concurrency here has no upside: the experiments are deterministic and the
    only shared resource is the output directory. So we simply forbid it.
    """
    if os.path.exists(LOCKFILE):
        try:
            info = open(LOCKFILE).read().strip()
        except OSError:
            info = "unreadable"
        pid = info.split()[0] if info else "?"
        alive = False
        try:
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))
            if h:
                alive = True
                ctypes.windll.kernel32.CloseHandle(h)
        except Exception:                                  # noqa: BLE001
            alive = True          # cannot tell: assume alive and refuse
        if alive:
            print("REFUSING TO START: another run appears active (%s)." % info)
            print("Lockfile: %s" % LOCKFILE)
            print("If you are certain no run is active, delete the lockfile.")
            sys.exit(2)
        print("Stale lockfile from dead PID %s; taking over." % pid)

    with open(LOCKFILE, "w") as fh:
        fh.write("%d started %s" % (os.getpid(), time.strftime("%Y-%m-%d %H:%M:%S")))


def release_lock():
    try:
        os.remove(LOCKFILE)
    except OSError:
        pass

YEARS = 3
THRESHOLDS = (0.25,)               # threshold proved non-influential; single value
REF_OVERSIZE = 1.60
REF_TANK = 12.0


# ===========================================================================
# helpers
# ===========================================================================
@contextlib.contextmanager
def override(pairs):
    """Temporarily override a list of (section, key, value) config entries."""
    saved = []
    for sec, key, val in pairs:
        d = getattr(C, sec)
        saved.append((d, key, d[key]))
        d[key] = val
    try:
        yield
    finally:
        for d, key, old in saved:
            d[key] = old


def cycle_tolerance(dRf=None):
    """N_tol: start/stop cycles to exhaust the irreversible-fouling budget."""
    f = C.FOULING
    if dRf is None:
        dRf = f["dRf_per_restart"]
    _, R_replace, _ = F.degradation_shadow_price()
    if dRf <= 0:
        return float("inf")
    return R_replace / (dRf * f["irreversible_fraction_restart"])


def dRf_from_N_tol(n_tol):
    """Inverse of cycle_tolerance: the coefficient implied by a cycle count."""
    f = C.FOULING
    _, R_replace, _ = F.degradation_shadow_price()
    if not np.isfinite(n_tol):
        return 0.0
    return R_replace / (n_tol * f["irreversible_fraction_restart"])


KEEP = ["policy", "pv_kWp", "batt_kWh", "tank_hours", "ro_oversize",
        "lcow_usd_m3", "sec_mean_kWh_m3", "re_fraction", "membrane_life_yr",
        "n_cip_per_yr", "n_replace_per_yr", "n_restart_per_yr",
        "capacity_factor", "unmet_frac", "pv_curtail_frac",
        "cost_elec", "cost_membrane", "cost_cip", "cost_capital",
        "cost_fixed", "cost_pv_clean", "rev_export",
        "ann_water_m3", "ann_delivered_m3", "ann_grid_kWh",
        "ann_pv_used_kWh", "co2_t_yr", "capex_usd"]


def row(res, **extra):
    d = {k: res[k] for k in KEEP}
    d.update(extra)
    return d


AGGRESSIONS = (0.0, 0.35, 0.70, 1.0)


def best_flex(resource, pv_kWp, deg_weight, oversize=REF_OVERSIZE,
              tank=REF_TANK, years=YEARS, thresholds=THRESHOLDS,
              aggressions=AGGRESSIONS):
    """Best dispatch for a given degradation weight.

    The designer searches over BOTH the PV threshold and the flexibility
    aggression, optimising under their OWN objective:

      deg_weight = 0 -> membrane replacement cost is invisible to them, so
                        they minimise every cost EXCEPT membranes
      deg_weight = 1 -> they minimise true LCOW

    The search space includes aggression = 0 (steady baseload), so a
    degradation-aware designer is free to conclude that the optimal amount of
    flexibility is none. Both cases report TRUE LCOW, so the comparison
    measures what the blind designer actually ends up paying.
    """
    # Threshold is irrelevant when aggression is zero, so evaluate that
    # degenerate (steady-baseload) case exactly once.
    combos = [(thresholds[0], 0.0)]
    combos += [(th, ag) for th in thresholds for ag in aggressions if ag > 0.0]

    best, best_obj, fallback = None, float("inf"), None
    for th, ag in combos:
        pol = S.make_flex_policy(pv_threshold=th, deg_weight=deg_weight,
                                 aggression=ag)
        pol.label = "flex_%s" % ("blind" if deg_weight == 0 else "aware")
        r = S.simulate(pol, pv_kWp=pv_kWp, tank_hours=tank,
                       ro_oversize=oversize, years=years, resource=resource)
        r["_threshold"], r["_aggression"] = th, ag
        if fallback is None:
            fallback = r
        if r["unmet_frac"] > 0.02:          # design fails the obligation
            continue
        if deg_weight == 0:
            obj = (r["cost_elec"] + r["cost_capital"] + r["cost_fixed"]
                   + r["cost_cip"] + r["cost_pv_clean"] - r["rev_export"])
        else:
            obj = r["lcow_usd_m3"]
        if obj < best_obj:
            best_obj, best = obj, r
            best["_designer_objective"] = obj
    if best is None:                        # no feasible combo
        fallback["_designer_objective"] = float("nan")
        return fallback
    return best


# ===========================================================================
# E1 — calibration
# ===========================================================================
def e1_calibration():
    print("\n" + "=" * 74)
    print("E1  MODEL CALIBRATION")
    print("=" * 74)
    txt = P.calibration_report() + "\n\n" + F.calibration_report()
    txt += "\n\nCycle tolerance at default dRf=%.4f : N_tol = %.0f cycles" % (
        C.FOULING["dRf_per_restart"], cycle_tolerance())
    txt += "\n  (at ~360 starts/yr for solar-following, that is %.1f years" \
           " of daily cycling)" % (cycle_tolerance() / 360.0)
    print(txt)
    with open(os.path.join(RESDIR, "E1_calibration.txt"), "w") as fh:
        fh.write(txt + "\n")

    rows = []
    for doy in range(1, 366, 7):
        T = float(P.sst_profile(doy))
        rows.append(dict(
            doy=doy, T_sea_C=T, tcf=float(P.tcf(T)),
            sec_kWh_m3=float(P.sec_total_kWh_m3(
                C.SEAWATER["salinity_g_L"], T, C.RO["recovery"], 0.0, 1.0)),
            foul_rate_op=float(F.fouling_rate_operating(T, 1.0)),
            foul_rate_idle=float(F.fouling_rate_idle(T)),
            pi_conc_bar=float(P.osmotic_pressure_bar(
                P.concentrate_salinity(C.SEAWATER["salinity_g_L"],
                                       C.RO["recovery"]), T)),
        ))
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESDIR, "E1_seasonal.csv"), index=False)
    print("\nSeasonal tension (the mechanism behind the result):")
    imin, imax = df.sec_kWh_m3.idxmin(), df.sec_kWh_m3.idxmax()
    print("  SEC minimum  %.3f kWh/m3 at %.1f C (doy %d)  <- summer"
          % (df.sec_kWh_m3[imin], df.T_sea_C[imin], df.doy[imin]))
    print("  SEC maximum  %.3f kWh/m3 at %.1f C (doy %d)  <- winter"
          % (df.sec_kWh_m3[imax], df.T_sea_C[imax], df.doy[imax]))
    print("  fouling rate varies %.2fx across the year (min %.2e, max %.2e)"
          % (df.foul_rate_op.max() / df.foul_rate_op.min(),
             df.foul_rate_op.min(), df.foul_rate_op.max()))
    print("  => the season with the CHEAPEST energy has the FASTEST fouling")
    return df


# ===========================================================================
# E2 — controlled policy comparison
# ===========================================================================
def e2_policies(resource, pv_ref):
    print("\n" + "=" * 74)
    print("E2  CONTROLLED POLICY COMPARISON")
    print("=" * 74)
    print("flex_blind and flex_aware share dispatch structure and day-ahead")
    print("foresight; they differ ONLY in the degradation weight.\n")

    rows = []
    for name, ovr, tank in [("conventional", 1.09, 6.0),
                            ("flex-enabled", REF_OVERSIZE, REF_TANK)]:
        print("--- %s design (oversize %.2f, %.0f h tank) ---" % (name, ovr, tank))
        for pol in ["baseload_grid", "pv_baseload"]:
            r = S.simulate(pol, pv_kWp=pv_ref, tank_hours=tank,
                           ro_oversize=ovr, years=YEARS, resource=resource)
            print("   " + S.summarize(r))
            rows.append(row(r, design=name))
        for w in (0.0, 1.0):
            r = best_flex(resource, pv_ref, w, oversize=ovr, tank=tank)
            print("   " + S.summarize(r))
            rows.append(row(r, design=name, deg_weight=w,
                            threshold=r["_threshold"]))
        print("")
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESDIR, "E2_policies.csv"), index=False)
    return df


# ===========================================================================
# E3 — design space
# ===========================================================================
def e3_design_space(resource, pv_parity):
    print("\n" + "=" * 74)
    print("E3  DESIGN-SPACE SWEEP  (PV capacity x RO oversize)")
    print("=" * 74)
    pv_fracs = [0.0, 0.3, 0.6, 1.0]
    oversizes = [1.09, 1.35, 1.60]

    rows, n, t0 = [], 0, time.time()
    total = len(pv_fracs) * len(oversizes) * 3
    for ovr, pf in itertools.product(oversizes, pv_fracs):
        tank = 6.0 if ovr < 1.2 else REF_TANK
        pv = pf * pv_parity
        r = S.simulate("pv_baseload", pv_kWp=pv, tank_hours=tank,
                       ro_oversize=ovr, years=YEARS, resource=resource)
        rows.append(row(r, pv_frac_parity=pf, design_tank=tank, deg_weight=np.nan))
        n += 1
        for w in (0.0, 1.0):
            r = best_flex(resource, pv, w, oversize=ovr, tank=tank)
            rows.append(row(r, pv_frac_parity=pf, design_tank=tank, deg_weight=w))
            n += 1
        if n % 9 == 0:
            print("   %3d/%d (%.0fs)" % (n, total, time.time() - t0))

    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESDIR, "E3_design_space.csv"), index=False)

    print("\nLCOW-optimal design, by policy (feasible designs only):")
    ok = df[df.unmet_frac < 0.02]
    for lab, sub in [("pv_baseload", ok[ok.policy == "pv_baseload"]),
                     ("flex_blind", ok[ok.policy == "flex_blind"]),
                     ("flex_aware", ok[ok.policy == "flex_aware"])]:
        if sub.empty:
            continue
        b = sub.loc[sub.lcow_usd_m3.idxmin()]
        print("   %-12s LCOW %.3f | PV %.2fx parity | oversize %.2f | "
              "RE %.1f%% | memlife %.2f yr"
              % (lab, b.lcow_usd_m3, b.pv_frac_parity, b.ro_oversize,
                 100 * b.re_fraction, b.membrane_life_yr))
    return df


# ===========================================================================
# E4 — cycle-tolerance frontier (1D)
# ===========================================================================
def e4_cycle_frontier(resource, pv_ref):
    print("\n" + "=" * 74)
    print("E4  CYCLE-TOLERANCE FRONTIER")
    print("=" * 74)
    print("N_tol = start/stop cycles the membrane tolerates before its")
    print("irreversible-fouling budget is exhausted. Solar-following implies")
    print("~360 starts/yr, so N_tol/360 is the membrane life under cycling.\n")

    n_tols = [250, 500, 1000, 2000, 4000, 8000, np.inf]
    rows = []
    print("%-9s %-8s | %-9s %-9s %-9s | %-9s %-8s" %
          ("N_tol", "yr@360", "baseload", "blind", "aware",
           "d_aware", "verdict"))
    print("-" * 76)
    for nt in n_tols:
        dRf = dRf_from_N_tol(nt)
        with override([("FOULING", "dRf_per_restart", dRf),
                       ("ECON", "tariff_spread", 0.25)]):
            base = S.simulate("pv_baseload", pv_kWp=pv_ref, tank_hours=REF_TANK,
                              ro_oversize=REF_OVERSIZE, years=YEARS,
                              resource=resource)
            bl = best_flex(resource, pv_ref, 0.0)
            aw = best_flex(resource, pv_ref, 1.0)
            for r, lab in [(base, "pv_baseload"), (bl, "flex_blind"),
                           (aw, "flex_aware")]:
                rows.append(row(r, N_tol=nt, dRf_per_restart=dRf, label=lab))
            d = aw["lcow_usd_m3"] - base["lcow_usd_m3"]
            print("%-9s %-8.1f | %-9.3f %-9.3f %-9.3f | %+9.3f %-8s" %
                  ("inf" if not np.isfinite(nt) else "%.0f" % nt,
                   nt / 360.0 if np.isfinite(nt) else 99.9,
                   base["lcow_usd_m3"], bl["lcow_usd_m3"], aw["lcow_usd_m3"],
                   d, "FLEX PAYS" if d < 0 else "baseload"))
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESDIR, "E4_cycle_frontier.csv"), index=False)
    return df


# ===========================================================================
# E5 — 2D frontier: N_tol x biofouling severity
# ===========================================================================
def e5_frontier_2d(resource, pv_ref):
    print("\n" + "=" * 74)
    print("E5  TWO-DIMENSIONAL FRONTIER: N_tol x biofouling index")
    print("=" * 74)
    n_tols = [250, 500, 1000, 2000, 4000, np.inf]
    bios = [1.0, 2.0, 4.0]
    rows = []
    print("Delta = LCOW(flex,aware) - LCOW(PV+baseload); negative => flex pays\n")
    print("%-8s |" % "N_tol", end="")
    for b in bios:
        print(" %10s" % ("B=%.1f" % b), end="")
    print("\n" + "-" * (10 + 11 * len(bios)))
    for nt in n_tols:
        dRf = dRf_from_N_tol(nt)
        print("%-8s |" % ("inf" if not np.isfinite(nt) else "%.0f" % nt), end="")
        for b in bios:
            with override([("FOULING", "dRf_per_restart", dRf),
                           ("SEAWATER", "biofouling_index", b),
                           ("ECON", "tariff_spread", 0.25)]):
                base = S.simulate("pv_baseload", pv_kWp=pv_ref,
                                  tank_hours=REF_TANK, ro_oversize=REF_OVERSIZE,
                                  years=YEARS, resource=resource)
                aw = best_flex(resource, pv_ref, 1.0)
                d = aw["lcow_usd_m3"] - base["lcow_usd_m3"]
                rows.append(dict(N_tol=nt, dRf_per_restart=dRf,
                                 biofouling_index=b, delta_lcow=d,
                                 lcow_base=base["lcow_usd_m3"],
                                 lcow_flex=aw["lcow_usd_m3"],
                                 re_base=base["re_fraction"],
                                 re_flex=aw["re_fraction"],
                                 memlife_base=base["membrane_life_yr"],
                                 memlife_flex=aw["membrane_life_yr"]))
                print(" %+9.3f%s" % (d, "*" if d < 0 else " "), end="")
        print("")
    print("\n'*' = flexibility economic")
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESDIR, "E5_frontier_2d.csv"), index=False)
    return df


# ===========================================================================
# E6 — tariff-spread frontier
# ===========================================================================
def e6_tariff_frontier(resource, pv_ref):
    print("\n" + "=" * 74)
    print("E6  TARIFF-SPREAD FRONTIER: N_tol x time-of-use spread")
    print("=" * 74)
    n_tols = [500, 1000, 2000, np.inf]
    spreads = [0.0, 0.25, 0.50, 1.00]
    rows = []
    print("%-8s |" % "N_tol", end="")
    for s in spreads:
        print(" %10s" % ("s=%.2f" % s), end="")
    print("\n" + "-" * (10 + 11 * len(spreads)))
    for nt in n_tols:
        dRf = dRf_from_N_tol(nt)
        print("%-8s |" % ("inf" if not np.isfinite(nt) else "%.0f" % nt), end="")
        for sp in spreads:
            with override([("FOULING", "dRf_per_restart", dRf),
                           ("ECON", "tariff_spread", sp)]):
                base = S.simulate("pv_baseload", pv_kWp=pv_ref,
                                  tank_hours=REF_TANK, ro_oversize=REF_OVERSIZE,
                                  years=YEARS, resource=resource)
                aw = best_flex(resource, pv_ref, 1.0)
                d = aw["lcow_usd_m3"] - base["lcow_usd_m3"]
                rows.append(dict(N_tol=nt, tariff_spread=sp, delta_lcow=d,
                                 lcow_base=base["lcow_usd_m3"],
                                 lcow_flex=aw["lcow_usd_m3"],
                                 re_flex=aw["re_fraction"]))
                print(" %+9.3f%s" % (d, "*" if d < 0 else " "), end="")
        print("")
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESDIR, "E6_tariff_frontier.csv"), index=False)
    return df


# ===========================================================================
# E7 — cost of degradation-blind design
# ===========================================================================
def e7_cost_of_blindness(resource, pv_parity, df3):
    print("\n" + "=" * 74)
    print("E7  COST OF DESIGNING WITH A DEGRADATION-BLIND MODEL")
    print("=" * 74)
    ok = df3[df3.unmet_frac < 0.02]
    bl = ok[ok.policy == "flex_blind"].copy()
    aw = ok[ok.policy == "flex_aware"].copy()
    base = ok[ok.policy == "pv_baseload"].copy()
    if bl.empty or aw.empty:
        print("  insufficient feasible designs")
        return {}

    bl["apparent"] = (bl.cost_elec + bl.cost_capital + bl.cost_fixed
                      + bl.cost_cip + bl.cost_pv_clean - bl.rev_export)
    pb = bl.loc[bl.apparent.idxmin()]
    pa = aw.loc[aw.lcow_usd_m3.idxmin()]
    pbase = base.loc[base.lcow_usd_m3.idxmin()]

    print("Degradation-BLIND designer selects PV %.2fx parity, oversize %.2f"
          % (pb.pv_frac_parity, pb.ro_oversize))
    print("   apparent LCOW (membranes excluded) : %.3f $/m3" % pb.apparent)
    print("   ACTUAL LCOW once degradation counts: %.3f $/m3" % pb.lcow_usd_m3)
    print("   realised membrane life %.2f yr, %.0f restarts/yr, RE %.1f%%"
          % (pb.membrane_life_yr, pb.n_restart_per_yr, 100 * pb.re_fraction))
    print("   model error: %+.1f%%"
          % (100 * (pb.lcow_usd_m3 / pb.apparent - 1)))

    print("\nDegradation-AWARE designer selects PV %.2fx parity, oversize %.2f"
          % (pa.pv_frac_parity, pa.ro_oversize))
    print("   LCOW %.3f $/m3, membrane life %.2f yr, RE %.1f%%"
          % (pa.lcow_usd_m3, pa.membrane_life_yr, 100 * pa.re_fraction))

    print("\nPV + steady baseload (current practice) best: PV %.2fx parity, "
          "oversize %.2f" % (pbase.pv_frac_parity, pbase.ro_oversize))
    print("   LCOW %.3f $/m3, RE %.1f%%"
          % (pbase.lcow_usd_m3, 100 * pbase.re_fraction))

    gap = pb.lcow_usd_m3 - min(pa.lcow_usd_m3, pbase.lcow_usd_m3)
    print("\n  >>> PENALTY FOR DESIGNING BLIND: %+.3f $/m3 (%+.1f%%)"
          % (gap, 100 * gap / min(pa.lcow_usd_m3, pbase.lcow_usd_m3)))

    out = {k: float(v) for k, v in dict(
        blind_pv_frac=pb.pv_frac_parity, blind_oversize=pb.ro_oversize,
        blind_apparent=pb.apparent, blind_actual=pb.lcow_usd_m3,
        blind_memlife=pb.membrane_life_yr, blind_restarts=pb.n_restart_per_yr,
        blind_re=pb.re_fraction,
        aware_pv_frac=pa.pv_frac_parity, aware_oversize=pa.ro_oversize,
        aware_lcow=pa.lcow_usd_m3, aware_memlife=pa.membrane_life_yr,
        aware_re=pa.re_fraction,
        baseload_pv_frac=pbase.pv_frac_parity,
        baseload_oversize=pbase.ro_oversize,
        baseload_lcow=pbase.lcow_usd_m3, baseload_re=pbase.re_fraction,
        penalty_usd_m3=gap,
    ).items()}
    with open(os.path.join(RESDIR, "E7_cost_of_blindness.json"), "w") as fh:
        json.dump(out, fh, indent=2)
    return out


# ===========================================================================
# E8 — sensitivity
# ===========================================================================
def e8_sensitivity(resource, pv_ref):
    print("\n" + "=" * 74)
    print("E8  ONE-AT-A-TIME SENSITIVITY")
    print("=" * 74)
    rows = []
    for section, key, values in C.SENSITIVITY_KEYS:
        base_val = getattr(C, section)[key]
        for v in values:
            with override([(section, key, v), ("ECON", "tariff_spread", 0.25)]):
                b = S.simulate("pv_baseload", pv_kWp=pv_ref,
                               tank_hours=REF_TANK, ro_oversize=REF_OVERSIZE,
                               years=YEARS, resource=resource)
                aw = best_flex(resource, pv_ref, 1.0)
                for r, lab in [(b, "pv_baseload"), (aw, "flex_aware")]:
                    rows.append(row(r, param="%s.%s" % (section, key),
                                    value=v, is_base=(v == base_val),
                                    label=lab))
        sub = pd.DataFrame([x for x in rows
                           if x["param"] == "%s.%s" % (section, key)])
        bb = sub[sub.label == "pv_baseload"]
        print("  %-34s baseload LCOW %.3f-%.3f  (range %.3f)"
              % ("%s.%s" % (section, key), bb.lcow_usd_m3.min(),
                 bb.lcow_usd_m3.max(),
                 bb.lcow_usd_m3.max() - bb.lcow_usd_m3.min()))
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESDIR, "E8_sensitivity.csv"), index=False)
    return df


# ===========================================================================
def main():
    t0 = time.time()
    acquire_lock()
    try:
        return _main_body(t0)
    finally:
        release_lock()


def _main_body(t0):
    resource = S.load_resource()
    pv_parity = C.DEMAND_M3_DAY * 365 * 3.9 / 1700.0
    pv_ref = 0.6 * pv_parity

    print("Site: %s" % C.SITE["name"])
    print("Water obligation %.0f m3/day | PV energy-parity %.0f kWp | "
          "reference PV %.0f kWp" % (C.DEMAND_M3_DAY, pv_parity, pv_ref))
    print("Resource: GHI %.0f kWh/m2/yr | mean AOD55 %.3f | Tsea %.1f-%.1f C"
          % (resource["ghi"].sum() / 1000, resource["aod_mean"],
             resource["tsea"].min(), resource["tsea"].max()))
    print("Default N_tol = %.0f cycles (%.1f yr of daily cycling)"
          % (cycle_tolerance(), cycle_tolerance() / 360.0))

    which = [w.lower() for w in sys.argv[1:]] or \
        ["e1", "e2", "e3", "e4", "e5", "e6", "e7", "e8"]

    df3 = None
    if "e1" in which:
        e1_calibration()
    if "e2" in which:
        e2_policies(resource, pv_ref)
    if "e3" in which:
        df3 = e3_design_space(resource, pv_parity)
    if "e4" in which:
        e4_cycle_frontier(resource, pv_ref)
    if "e5" in which:
        e5_frontier_2d(resource, pv_ref)
    if "e6" in which:
        e6_tariff_frontier(resource, pv_ref)
    if "e7" in which:
        if df3 is None:
            df3 = pd.read_csv(os.path.join(RESDIR, "E3_design_space.csv"))
        e7_cost_of_blindness(resource, pv_parity, df3)
    if "e8" in which:
        e8_sensitivity(resource, pv_ref)

    print("\nTotal runtime %.0f s" % (time.time() - t0))


if __name__ == "__main__":
    main()
