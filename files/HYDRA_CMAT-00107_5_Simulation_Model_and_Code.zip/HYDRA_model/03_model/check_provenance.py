"""
check_provenance.py — Guard against reporting stale results.

Motivation. During development a results directory accumulated a file whose
contents looked plausible but which had been written by an earlier, buggy
version of the dispatch policy. It was detectable only by two cross-checks:
its modification time preceded that of an experiment which runs before it, and
its parameter grid did not match the grid in the current source.

Content alone cannot distinguish a stale result from a fresh one. This script
runs both checks, and is intended to be executed before any figure generation
or manuscript number update.

Usage:  python check_provenance.py
Exit code 0 = all clear, 1 = suspect files found.
"""

import os
import sys

import numpy as np
import pandas as pd

import config as C
import run_experiments as RX

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")

# Experiments in execution order. A file must not be older than the file of
# any experiment that runs before it.
ORDER = ["E1_seasonal.csv", "E2_policies.csv", "E3_design_space.csv",
         "E4_cycle_frontier.csv", "E5_frontier_2d.csv",
         "E6_tariff_frontier.csv", "E8_sensitivity.csv"]


def mtime(fn):
    p = os.path.join(RES, fn)
    return os.path.getmtime(p) if os.path.exists(p) else None


def check_order():
    """Each file must be at least as new as every earlier-running file."""
    problems = []
    seen = []
    for fn in ORDER:
        t = mtime(fn)
        if t is None:
            continue
        for pfn, pt in seen:
            if t < pt:
                problems.append(
                    "%s (%s) is OLDER than %s (%s), but runs after it"
                    % (fn, _fmt(t), pfn, _fmt(pt)))
        seen.append((fn, t))
    return problems


def _fmt(t):
    import datetime
    return datetime.datetime.fromtimestamp(t).strftime("%H:%M:%S")


def check_grids():
    """Each file's parameter grid must match the grid in the current source."""
    problems = []

    # E5: biofouling grid
    p = os.path.join(RES, "E5_frontier_2d.csv")
    if os.path.exists(p):
        got = sorted(pd.read_csv(p).biofouling_index.unique())
        # the grid is written inline in e5_frontier_2d; keep in sync here
        want = sorted([1.0, 2.0, 4.0])
        if got != want:
            problems.append("E5 biofouling grid is %s, source expects %s"
                            % (got, want))

    # E6: tariff grid
    p = os.path.join(RES, "E6_tariff_frontier.csv")
    if os.path.exists(p):
        got = sorted(pd.read_csv(p).tariff_spread.unique())
        want = sorted([0.0, 0.25, 0.50, 1.00])
        if got != want:
            problems.append("E6 tariff grid is %s, source expects %s"
                            % (got, want))

    # E3: design grid
    p = os.path.join(RES, "E3_design_space.csv")
    if os.path.exists(p):
        d = pd.read_csv(p)
        got = sorted(d.ro_oversize.unique())
        want = sorted([1.09, 1.35, 1.60])
        if got != want:
            problems.append("E3 oversize grid is %s, source expects %s"
                            % (got, want))

    # E8: sensitivity parameters
    p = os.path.join(RES, "E8_sensitivity.csv")
    if os.path.exists(p):
        got = set(pd.read_csv(p).param.unique())
        want = set("%s.%s" % (s, k) for s, k, _ in C.SENSITIVITY_KEYS)
        missing = want - got
        extra = got - want
        if missing or extra:
            problems.append("E8 parameters mismatch; missing %s, unexpected %s"
                            % (sorted(missing), sorted(extra)))
    return problems


def check_present():
    return [fn for fn in ORDER if mtime(fn) is None]


def main():
    print("PROVENANCE CHECK on %s\n" % RES)

    missing = check_present()
    order = check_order()
    grids = check_grids()

    if missing:
        print("MISSING (experiment not yet run):")
        for m in missing:
            print("   %s" % m)
        print("")

    if order:
        print("!! MODIFICATION-ORDER VIOLATIONS (stale file suspected):")
        for m in order:
            print("   %s" % m)
        print("")

    if grids:
        print("!! GRID MISMATCHES (file written by a different source version):")
        for m in grids:
            print("   %s" % m)
        print("")

    if not order and not grids:
        print("All present files pass both checks.")
        if missing:
            print("Note: %d experiment(s) still missing." % len(missing))
        return 0

    print("ACTION: move the offending files out of results/ and re-run those")
    print("experiments before generating figures or updating the manuscript.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
