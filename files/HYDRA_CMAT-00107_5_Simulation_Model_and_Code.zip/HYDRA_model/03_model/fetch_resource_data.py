"""
fetch_resource_data.py
----------------------
Downloads real meteorological resource data for the Al Taweelah SWRO site
(Abu Dhabi, UAE) from the NASA POWER API.

Site: Al Taweelah IWP, approx. 24.75 N, 54.70 E  (world's largest SWRO plant,
909,200 m3/day, 68 MWp co-located PV).

Parameters retrieved (hourly, RE community):
  ALLSKY_SFC_SW_DWN  global horizontal irradiance          [W/m2]
  CLRSKY_SFC_SW_DWN  clear-sky GHI (used to infer aerosol/cloud attenuation)
  T2M                air temperature at 2 m                [C]
  WS10M              wind speed at 10 m                    [m/s]
  RH2M               relative humidity                     [%]

Daily aerosol optical depth is fetched separately (AOD_55 is not offered at
hourly resolution).

Output: data/taweelah_hourly_<year>.csv , data/taweelah_aod_<year>.csv
"""

import io
import os
import sys
import time
import json

import pandas as pd
import requests

LAT, LON = 24.75, 54.70          # Al Taweelah, Abu Dhabi
SITE = "taweelah"
YEAR = 2023                       # most recent complete year with full coverage
OUTDIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

HOURLY_URL = "https://power.larc.nasa.gov/api/temporal/hourly/point"
DAILY_URL = "https://power.larc.nasa.gov/api/temporal/daily/point"

HOURLY_PARAMS = ["ALLSKY_SFC_SW_DWN", "CLRSKY_SFC_SW_DWN", "T2M", "WS10M", "RH2M"]
DAILY_PARAMS = ["AOD_55", "ALLSKY_SFC_SW_DWN", "T2M"]


def _get(url, params, tries=4):
    """GET with retry/backoff; returns parsed JSON."""
    last = None
    for k in range(tries):
        try:
            r = requests.get(url, params=params, timeout=120)
            if r.status_code == 200:
                return r.json()
            last = "HTTP %s: %s" % (r.status_code, r.text[:300])
        except Exception as exc:                      # noqa: BLE001
            last = "%s: %s" % (type(exc).__name__, exc)
        time.sleep(3 * (k + 1))
    raise RuntimeError("NASA POWER request failed after %d tries -> %s" % (tries, last))


def fetch_hourly(year):
    q = {
        "parameters": ",".join(HOURLY_PARAMS),
        "community": "RE",
        "latitude": LAT,
        "longitude": LON,
        "start": "%d0101" % year,
        "end": "%d1231" % year,
        "format": "JSON",
        "time-standard": "UTC",
    }
    js = _get(HOURLY_URL, q)
    rec = js["properties"]["parameter"]
    df = pd.DataFrame({k: pd.Series(v) for k, v in rec.items()})
    df.index = pd.to_datetime(df.index, format="%Y%m%d%H", utc=True)
    df.index.name = "timestamp_utc"
    # NASA POWER uses -999 as fill
    df = df.replace(-999.0, pd.NA).astype("float64")
    # local time: UAE is UTC+4, no DST
    df["local_hour"] = (df.index.tz_convert("Asia/Dubai")).hour
    return df.sort_index()


def fetch_daily(year):
    q = {
        "parameters": ",".join(DAILY_PARAMS),
        "community": "RE",
        "latitude": LAT,
        "longitude": LON,
        "start": "%d0101" % year,
        "end": "%d1231" % year,
        "format": "JSON",
    }
    js = _get(DAILY_URL, q)
    rec = js["properties"]["parameter"]
    df = pd.DataFrame({k: pd.Series(v) for k, v in rec.items()})
    df.index = pd.to_datetime(df.index, format="%Y%m%d")
    df.index.name = "date"
    return df.replace(-999.0, pd.NA).astype("float64").sort_index()


def main():
    os.makedirs(OUTDIR, exist_ok=True)
    print("Fetching NASA POWER hourly data for %s (%.2f N, %.2f E), year %d ..."
          % (SITE, LAT, LON, YEAR))
    h = fetch_hourly(YEAR)
    hp = os.path.join(OUTDIR, "%s_hourly_%d.csv" % (SITE, YEAR))
    h.to_csv(hp)
    print("  hourly rows: %d  -> %s" % (len(h), hp))
    print("  GHI  mean %.1f W/m2, max %.1f W/m2"
          % (h["ALLSKY_SFC_SW_DWN"].mean(), h["ALLSKY_SFC_SW_DWN"].max()))
    print("  T2M  min %.1f C, mean %.1f C, max %.1f C"
          % (h["T2M"].min(), h["T2M"].mean(), h["T2M"].max()))
    print("  annual GHI: %.0f kWh/m2/yr" % (h["ALLSKY_SFC_SW_DWN"].sum() / 1000.0))

    print("\nFetching daily AOD ...")
    try:
        d = fetch_daily(YEAR)
        dp = os.path.join(OUTDIR, "%s_aod_%d.csv" % (SITE, YEAR))
        d.to_csv(dp)
        print("  daily rows: %d -> %s" % (len(d), dp))
        if "AOD_55" in d and d["AOD_55"].notna().any():
            print("  AOD_55 mean %.3f  p95 %.3f  max %.3f"
                  % (d["AOD_55"].mean(), d["AOD_55"].quantile(0.95), d["AOD_55"].max()))
        else:
            print("  AOD_55 unavailable at this point; clear-sky ratio will be used instead.")
    except Exception as exc:                          # noqa: BLE001
        print("  daily/AOD fetch failed (%s) -> will fall back to clear-sky ratio" % exc)

    print("\nDone.")


if __name__ == "__main__":
    sys.exit(main())
