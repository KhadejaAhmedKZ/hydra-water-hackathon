"""
config.py — All model parameters, each with a provenance tag.

PROVENANCE TAGS
  [LIT]  = taken from published literature (source named)
  [IND]  = industry/vendor figure (named; treated as lower-confidence)
  [DER]  = derived from first principles or from other parameters here
  [ASM]  = assumption made by this study (must appear in paper limitations)
  [DATA] = measured/reanalysis data (NASA POWER)

Every [ASM] entry is a candidate for the sensitivity analysis.
Nothing here is a placeholder invented for convenience: unsourced values are
labelled [ASM] explicitly so they can be challenged.
"""

# ----------------------------------------------------------------------------
# 1. SITE
# ----------------------------------------------------------------------------
SITE = dict(
    name="Al Taweelah IWP (Abu Dhabi, UAE)",
    lat=24.75,                  # [DATA]
    lon=54.70,                  # [DATA]
    tz="Asia/Dubai",            # UTC+4, no DST
    # Al Taweelah design capacity: 200 MIGD = 909,200 m3/day
    capacity_m3_day=909_200.0,  # [IND] ACWA Power / EWEC project disclosures
    pv_installed_MWp=69.0,      # [IND] "about 69 MW", pv magazine 23 Jun 2022 (citing ACWA Power)
    pv_share_contracted=0.30,   # [IND] share of electricity CAPACITY within 8 yr (ACWA/EWEC, 23 Jun 2022)
    pv_share_target=0.55,       # [IND] capacity-share target, end of first quarter-life (ACWA/EWEC)
)

# Model is run on a single representative train to keep runtimes tractable,
# then scaled. 1 train = 1/20 of plant.
TRAIN_FRACTION = 0.05           # [ASM] modelling convenience
TRAIN_CAPACITY_M3_DAY = SITE["capacity_m3_day"] * TRAIN_FRACTION

# IMPORTANT DISTINCTION.
# The WATER OBLIGATION is fixed: the utility must be supplied regardless of
# how the plant is built. RO CAPACITY is then a DESIGN VARIABLE. Building RO
# capacity in excess of the obligation is what buys operational flexibility --
# the plant can then concentrate production into sunlit hours and idle
# otherwise. Oversizing costs capital and, as this study shows, membrane life.
# Conventional plants are built at oversize ~1.09 (i.e. 92% mean utilisation),
# which leaves almost no flexibility headroom.
DEMAND_M3_DAY = TRAIN_CAPACITY_M3_DAY * 0.92   # fixed water obligation
RO_OVERSIZE_DEFAULT = 1.09                      # conventional design point

# ----------------------------------------------------------------------------
# 2. GULF SEAWATER PROPERTIES
# ----------------------------------------------------------------------------
SEAWATER = dict(
    # Arabian Gulf salinity: basin average 39 psu (Omerspahic et al., Front.
    # Mar. Sci. 9:845113, 2022); a Gulf pilot intake recorded 47.5-53.5 g/L
    # (Kim & Hong, Desalination 565:116871, 2023). 45 g/L is a design choice
    # between the two.
    salinity_g_L=45.0,          # [ASM] design value between 39 psu basin average and 47.5-53.5 g/L pilot intake
    salinity_range=(39.0, 47.0),# [LIT] sensitivity band

    # Gulf sea-surface temperature seasonal cycle. Shallow (~35 m mean depth)
    # semi-enclosed basin -> large annual swing.
    sst_min_C=20.0,             # [ASM] intake value; basin surface falls below 15 C in winter (Omerspahic 2022)
    sst_max_C=35.0,             # [ASM] intake value; basin surface reaches 36 C in summer (Omerspahic 2022)
    sst_mean_C=27.5,            # [DER] midpoint
    sst_peak_doy=225,           # [ASM] mid-August peak

    # Osmotic coefficient for seawater treated as NaCl-equivalent.
    # van't Hoff with phi=1 gives 29.7 bar at 35 g/L, 25 C; phi=0.93 gives
    # 27.6 bar. Treated as a standard engineering value; full seawater property
    # correlations are given by Sharqawy, Lienhard & Zubair (Desal. Water
    # Treat. 16:354, 2010).
    osmotic_coeff=0.93,         # [ENG] NaCl-equivalent osmotic coefficient; consistency value

    # Biofouling propensity. Serious membrane biofouling is documented at an
    # operating Gulf SWRO plant (Winters et al., Desalination 529, 2022) and
    # algal-bloom turbidity at a Gulf pilot (Kim & Hong, Desalination 565,
    # 2023). No verified Gulf cell-count range is used. We normalise to a
    # dimensionless index where 1.0 = open-ocean baseline and the Gulf design
    # value reflects the elevated load.
    #
    # CALIBRATION NOTE. This is the LEAST-CONSTRAINED parameter in the model
    # and the primary target for validation against plant data. k_bio_ref is
    # set so the open-ocean baseline (index 1.0, 25 C) reaches the cleaning
    # trigger in about 4.7 months; that interval is an assumption, not a
    # sourced industrial value. A full-scale SWRO plant reports a 20-day
    # cleaning frequency (Chen et al., Water Res. 249:120914, 2024), so real
    # fouling may be faster; the index sweep spans that. Index 2.0 predicts a
    # ~1.6 month Gulf interval. Results are reported across the swept range.
    biofouling_index=2.0,       # [ASM] conservative; swept 1.0-6.0
    biofouling_index_range=(1.0, 6.0),  # sensitivity
)

M_NACL = 58.44          # g/mol
R_GAS = 0.083145        # L*bar/(mol*K)

# ----------------------------------------------------------------------------
# 3. RO PROCESS
# ----------------------------------------------------------------------------
RO = dict(
    recovery=0.40,              # [ASM] above the 31-34% reported for stable high-salinity high-temperature operation (Kim et al., Desalination 2020)
    recovery_range=(0.33, 0.45),

    # Clean water permeability at 25 C for seawater polyamide membrane
    A_clean_25=1.0,             # [ENG] L/(m2*h*bar), typical SWRO element; not individually sourced
    # Temperature correction: TCF = exp[Ke*(1/298.15 - 1/T)]
    # Ke for polyamide RO reported in range 2500-5500; 2700 is the standard
    # manufacturer value for T >= 25 C.
    Ke_tcf=2700.0,              # [IND] manufacturer normalisation (vendor range 2500-5500); plant surveys find temperature effects unclear (Kim et al. 2019)

    design_flux_LMH=13.0,       # [ENG] typical SWRO design flux L/(m2*h); not individually sourced
    salt_rejection=0.995,       # [DER] within 0.990-0.995 implied by 250-455 mg/L permeate from 47.5-53.5 g/L feed (Kim & Hong 2023)

    eta_hpp=0.85,               # [ENG] high-pressure pump efficiency; Karameldin et al. 2018 use 0.80
    eta_erd=0.94,               # [LIT] positive-displacement ERDs 92-96% net transfer (Karameldin et al., DWT 118:49, 2018)
    dp_friction_bar=2.0,        # [ASM] feed-channel pressure drop

    # Energy outside the high-pressure stage: intake, pretreatment, post-
    # treatment, product pumping. Reported plant-total minus process SEC.
    sec_auxiliary_kWh_m3=0.50,  # [ENG] conventional pretreatment allowance; MTF cut pretreatment energy 77% at a Gulf pilot (Kim & Hong 2023)

    # Operating envelope for load-following
    load_min=0.40,              # [ASM] minimum stable train load fraction
    load_max=1.00,
)

# ----------------------------------------------------------------------------
# 4. FOULING / DEGRADATION  <-- the novel core of this study
# ----------------------------------------------------------------------------
# Fouling is represented as an additive hydraulic resistance R_f that reduces
# effective permeability:   1/A_eff = 1/A_clean(T) + R_f
# R_f has a REVERSIBLE part (removed by clean-in-place) and an IRREVERSIBLE
# part (removed only by membrane replacement).
FOULING = dict(
    # Baseline reversible accumulation during steady operation, expressed as
    # resistance gained per 1000 h at reference conditions (25 C, ocean
    # biofouling index 1.0, full load). Set so an open-ocean baseload plant
    # reaches the cleaning trigger in about 4.7 months. This is an assumption:
    # a full-scale SWRO plant reports a 20-day cleaning frequency (Chen et al.
    # 2024), and faster fouling is spanned by the biofouling-index sweep.
    k_bio_ref=0.045,            # [ASM] set to a 4.7-month open-ocean cleaning interval; not calibrated to plant data

    # Biological growth temperature sensitivity (Q10). Microbial growth rate
    # roughly doubles per 10 C rise over this range.
    Q10=2.0,                    # [ENG] first-order microbial growth approximation; not individually sourced
    T_ref_C=25.0,

    # Shear-removal exponent. At reduced load, crossflow velocity falls, shear
    # removal of nascent biofilm weakens, and NET accumulation rises.
    # rate_multiplier = load^(-alpha_shear)
    alpha_shear=0.8,            # [ASM] KEY UNCERTAIN PARAMETER - sensitivity swept

    # Stagnation penalty: during idle hours there is no crossflow at all, so
    # biofilm develops unchecked. Expressed as multiple of the full-load rate.
    idle_multiplier=2.5,        # [ASM] KEY UNCERTAIN PARAMETER - sensitivity swept

    # Per-restart increment. Each start applies a pressure/flux transient that
    # compacts deposits and drives a step of partly irreversible resistance.
    dRf_per_restart=0.004,      # [ASM] KEY UNCERTAIN PARAMETER - sensitivity swept

    # Fraction of newly-formed resistance that is irreversible
    irreversible_fraction=0.12, # [ASM]
    # ... and the elevated irreversible fraction for restart-induced fouling
    irreversible_fraction_restart=0.35,  # [ASM] compaction is harder to reverse

    # Scaling contribution, driven by concentrate saturation. Rises steeply
    # with recovery; secondary to biofouling in the Gulf.
    k_scale_ref=0.010,          # [ASM]

    # Clean-in-place
    cip_trigger_perm_ratio=0.85,# [ENG] cleaning at ~15% permeability loss; not individually sourced
    cip_reversible_recovery=0.92,# [ASM] fraction of reversible R_f removed
    cip_downtime_h=8.0,         # [ASM]
    cip_cost_usd_per_train=4_500.0,  # [ASM]
    # Minimum interval between cleanings. Without this, a pure threshold rule
    # "thrashes": as irreversible fouling accumulates the trigger is re-crossed
    # almost immediately after each clean, producing physically absurd cleaning
    # frequencies. Real plants are limited by chemical handling, downtime and
    # the fact that aggressive cleaning itself damages membranes. One month is
    # the practical floor reported for severely-fouling seawater plants.
    cip_min_interval_h=720.0,   # [ASM] one month
    cip_max_per_year=12,        # [DER] follows from the minimum interval

    # Membrane replacement when irreversible loss makes design flux
    # unattainable within the pressure limit
    replace_perm_ratio=0.70,    # [ASM]
    membrane_life_max_years=5.0,# [ENG] ceiling; a full-scale SWRO plant ran 7 yr with 40% flux decline (Chen et al. 2024)
    membrane_life_min_years=1.0,# floor
)

# ----------------------------------------------------------------------------
# 5. PV
# ----------------------------------------------------------------------------
PV = dict(
    # Module + inverter
    eta_stc=0.205,              # [ASM] modern mono-PERC/TOPCon module efficiency
    temp_coeff_pmax=-0.0034,    # [ENG] /K, typical crystalline silicon; not individually sourced
    noct_C=45.0,                # [ASM] nominal operating cell temperature
    inverter_eta=0.98,          # [ASM]
    dc_ac_ratio=1.2,            # [ASM]
    other_losses=0.04,          # [ASM] wiring, mismatch, availability

    # SOILING - Gulf-specific. Soiling loss is driven by aerosol deposition.
    # NASA POWER AOD_55 at this site: mean 0.545, p95 0.99, max 1.38.
    # Loss accumulates between cleanings and is reset by washing.
    soiling_rate_per_day_per_AOD=0.0045,  # [ASM] KEY UNCERTAIN - sensitivity swept
    soiling_max=0.25,           # [ASM] saturation of soiling loss
    clean_interval_days=14,     # [ASM] PV washing frequency
    clean_cost_usd_per_m2=0.35, # [LIT] Nwafor et al. 2025 (arXiv:2507.10609)
)

# ----------------------------------------------------------------------------
# 6. STORAGE
# ----------------------------------------------------------------------------
STORAGE = dict(
    # Battery
    batt_eta_rt=0.90,           # [ASM] round-trip
    batt_dod=0.90,              # [ASM] usable depth of discharge
    batt_cycle_life=6000,       # [ASM]

    # Product-water tank: the cheap "battery" that stores WATER not electrons
    tank_loss_per_day=0.001,    # [ASM] negligible evaporation/leakage
    tank_max_hours=24.0,        # [ASM] max sizing considered
)

# ----------------------------------------------------------------------------
# 7. ECONOMICS
# ----------------------------------------------------------------------------
ECON = dict(
    discount_rate=0.055,        # [LIT] 5.5% real, Jubail SWRO TEA (Mohammed, JJEE 12:209, 2026)
    plant_life_years=25,        # [LIT] 25-year project life, Jubail SWRO TEA (Mohammed 2026)
    # UAE industrial electricity. Grid import price.
    elec_price_usd_kWh=0.040,   # [LIT] Nwafor et al. 2025 give 0.03-0.05
    elec_price_range=(0.030, 0.050),
    # Export/curtailment value of surplus PV
    elec_export_usd_kWh=0.020,  # [ASM] half of import price

    # TIME-OF-USE TARIFF SPREAD.
    # UAE industrial tariffs are today largely flat, which is precisely why
    # flexibility earns almost nothing: with a flat price there is no arbitrage
    # to capture and the only gain from load-following is avoiding low-value
    # PV export. As solar penetration rises, midday prices fall and evening
    # prices rise, creating the spread that rewards flexible load. We therefore
    # treat the spread as a POLICY VARIABLE and report the value at which
    # flexible operation becomes economic in Gulf fouling conditions.
    #
    #   price(t) = base * (1 + spread * shape(t)),  shape in [-1, +1]
    #   spread = 0.0  -> flat tariff (today)
    #   spread = 0.5  -> midday price half of base, evening peak 1.5x base
    tariff_spread=0.0,          # [ASM] baseline = today's flat tariff
    tariff_solar_hours=(10, 16),# [ASM] low-price window (local time)
    tariff_peak_hours=(18, 23), # [ASM] high-price window (local time)
    # Emissions factor for UAE grid electricity
    grid_co2_kg_kWh=0.40,       # [DER] between UAE 2019 baseline 0.55 and 2030 target 0.27 (Climate Action Tracker)

    # CAPEX
    ro_capex_usd_m3_day=1_200.0,# [ASM] SWRO plant capital per m3/day capacity
    pv_capex_usd_kWp=650.0,     # [ASM] utility-scale PV, Gulf
    batt_capex_usd_kWh=220.0,   # [ASM] utility-scale BESS
    tank_capex_usd_m3=90.0,     # [ASM] large product-water reservoir
    membrane_capex_usd_m2=22.0, # [ASM] element cost per membrane area

    # Fixed OPEX (excluding electricity, membranes, CIP which are modelled)
    # Labour 15-25% of OPEX, chemicals 5-15%, maintenance 10-15%
    opex_fixed_usd_m3=0.22,     # [DER] from OPEX share breakdown
    opex_fixed_range=(0.15, 0.32),
)

# ----------------------------------------------------------------------------
# 8. WATER DEMAND
# ----------------------------------------------------------------------------
DEMAND = dict(
    # Abu Dhabi water demand is strongly summer-peaking (cooling, irrigation).
    annual_mean_fraction=0.92,  # [ASM] plant runs at 92% of nameplate on average
    summer_peak_amplitude=0.12, # [ASM] +/- seasonal swing
    peak_doy=200,               # [ASM] mid-July
    diurnal_amplitude=0.05,     # [ASM] modest daily swing, tank-buffered
    # Contractual minimum daily delivery (take-or-pay style obligation)
    min_daily_delivery_frac=0.80,  # [ASM] must meet 80% of mean demand daily
)

# ----------------------------------------------------------------------------
# 9. PARAMETERS FLAGGED FOR SENSITIVITY ANALYSIS
# ----------------------------------------------------------------------------
# The conclusions must be shown to be robust (or not) to these.
SENSITIVITY_KEYS = [
    ("FOULING", "alpha_shear", [0.0, 0.4, 0.8, 1.2, 1.6]),
    ("FOULING", "idle_multiplier", [1.0, 1.75, 2.5, 3.5, 5.0]),
    ("FOULING", "dRf_per_restart", [0.000, 0.002, 0.004, 0.008, 0.016]),
    ("SEAWATER", "biofouling_index", [1.0, 2.0, 3.0, 4.5, 6.0]),
    ("ECON", "elec_price_usd_kWh", [0.030, 0.035, 0.040, 0.045, 0.050]),
    ("ECON", "pv_capex_usd_kWp", [450.0, 550.0, 650.0, 800.0, 1000.0]),
    ("ECON", "batt_capex_usd_kWh", [120.0, 170.0, 220.0, 300.0, 400.0]),
    ("SEAWATER", "salinity_g_L", [39.0, 42.0, 45.0, 47.0]),
]
