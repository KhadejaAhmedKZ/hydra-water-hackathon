"""
fouling.py — Cycling-dependent biofouling and membrane degradation.

This module is the novel contribution of the study. Existing renewable-
dispatch models for desalination (e.g. Alahmed, Botterud, Amin & Al-Awami,
arXiv:2601.02243, 2026) treat the RO plant as a static power-to-water
converter with a fixed conversion factor, and explicitly list ambient-
condition dependence and degradation as unmodelled future work. Conversely,
the experimental fouling literature shows that intermittent operation does
carry a penalty: accelerated scaling and fouling on brackish feed, mitigated but
not removed by rinsing and antiscalant (Freire-Gormaly & Bilton, Desalination
2018; J. Membr. Sci. 2019); about 50% permeability loss over 14 years at an
intermittent brackish plant (Ruiz-Garcia & Nuez, Desalination 2020); and 37%
permeability loss within three days for a seawater membrane under PV-emulated
variable operation without rinsing (Dimitriou et al., Water 2025). None of it
has been carried into dispatch models.

In the Arabian Gulf, surface temperatures reach 36 C (Omerspahic et al.,
Front. Mar. Sci. 2022), intake salinities above 47 g/L and algal-bloom
turbidity are recorded (Kim & Hong, Desalination 2023), and serious membrane
biofouling is documented at an operating SWRO plant (Winters et al.,
Desalination 2022). This module therefore couples the two literatures.

STATE
  R_rev    reversible fouling resistance   [m2*h*bar/L], removed by CIP
  R_irr    irreversible fouling resistance [m2*h*bar/L], removed only by
           membrane replacement

MECHANISMS REPRESENTED
  1. Baseline biofilm accumulation during operation, scaled by a Q10
     temperature law and by a dimensionless feed biofouling index.
  2. Shear-removal weakening at part load: crossflow velocity falls with
     load, so NET accumulation rises as load^(-alpha_shear).
  3. Stagnation during idle hours: no crossflow at all, so biofilm develops
     unchecked at idle_multiplier times the full-load rate.
  4. Per-restart step increment: each start applies a flux/pressure
     transient that compacts deposits, with an elevated irreversible share.
  5. Concentrate-side scaling, rising with recovery.

Every coefficient in mechanisms 2-4 is an explicit assumption flagged in
config.py and swept in the sensitivity analysis. The paper's conclusions are
reported as a function of these coefficients rather than as point claims.
"""

import numpy as np

import config as C
import physics as P


# ===========================================================================
# Instantaneous fouling rates
# ===========================================================================
def q10_factor(T_C, Q10=None, T_ref=None):
    """Temperature multiplier on biological growth rate.

        f = Q10 ** ((T - T_ref) / 10)

    Q10 = 2 means biofilm accumulation doubles per 10 C rise, the standard
    first-order approximation for microbial growth over this range.
    """
    f = C.FOULING
    if Q10 is None:
        Q10 = f["Q10"]
    if T_ref is None:
        T_ref = f["T_ref_C"]
    return Q10 ** ((np.asarray(T_C, dtype=float) - T_ref) / 10.0)


def fouling_rate_operating(T_C, load_fraction, biofouling_index=None,
                           recovery=None, cfg=None):
    """Resistance accrued per hour while the train is RUNNING.

        dR/dt = k_bio_ref * f_Q10(T) * B * L^(-alpha_shear)
                + k_scale_ref * (r / (1-r))

    Units: k_bio_ref is defined per 1000 h, so divide by 1000.
    """
    f = cfg if cfg is not None else C.FOULING
    if biofouling_index is None:
        biofouling_index = C.SEAWATER["biofouling_index"]
    if recovery is None:
        recovery = C.RO["recovery"]

    L = np.clip(np.asarray(load_fraction, dtype=float), 1e-3, 1.0)
    bio = (f["k_bio_ref"] / 1000.0) * q10_factor(T_C, f["Q10"], f["T_ref_C"]) \
        * biofouling_index * L ** (-f["alpha_shear"])
    scale = (f["k_scale_ref"] / 1000.0) * (recovery / (1.0 - recovery))
    return bio + scale


def fouling_rate_idle(T_C, biofouling_index=None, cfg=None):
    """Resistance accrued per hour while the train is IDLE (stagnant).

    No crossflow means no shear removal, so accumulation proceeds at
    idle_multiplier times the full-load biological rate. Scaling does not
    progress while idle (no concentration driving force).
    """
    f = cfg if cfg is not None else C.FOULING
    if biofouling_index is None:
        biofouling_index = C.SEAWATER["biofouling_index"]
    return (f["k_bio_ref"] / 1000.0) * q10_factor(T_C, f["Q10"], f["T_ref_C"]) \
        * biofouling_index * f["idle_multiplier"]


# ===========================================================================
# Membrane state container
# ===========================================================================
class MembraneState(object):
    """Tracks fouling state, CIP events and replacements for one train."""

    def __init__(self, cfg=None):
        self.f = cfg if cfg is not None else C.FOULING
        self.R_rev = 0.0
        self.R_irr = 0.0
        # Cumulative irreversible resistance ever accrued, NEVER reset by
        # replacement. Dividing this by the replacement budget R* gives a
        # continuous measure of membrane consumption.
        #
        # Why this is needed: annualising membrane cost from the integer
        # replacement COUNT quantises the cost to multiples of 1/horizon per
        # year, so on a 3-year run a membrane life of 1.5 yr and one of 2.4 yr
        # both register exactly one replacement and therefore identical cost.
        # That artefact masks precisely the effect this study measures.
        self.R_irr_cumulative = 0.0
        self.n_cip = 0
        self.n_replace = 0
        self.n_restart = 0
        self.cip_this_year = 0
        self.hours_since_cip = 0.0
        self.hours_total = 0.0
        self.downtime_h = 0.0
        self.running_prev = True
        # history of hours-to-replacement, for membrane-life statistics
        self.replace_intervals_h = []
        self._hours_since_replace = 0.0

    # -- derived quantities -------------------------------------------------
    @property
    def R_total(self):
        return self.R_rev + self.R_irr

    def perm_ratio(self, T_C):
        """A_eff / A_clean at the current state: the normalised permeability
        that plant operators actually trend."""
        return P.A_effective(T_C, self.R_total) / P.A_clean(T_C)

    # -- evolution ----------------------------------------------------------
    def step(self, dt_h, T_C, running, load_fraction,
             biofouling_index=None, recovery=None):
        """Advance the membrane state by dt_h hours.

        Returns dict of events that occurred in this step.
        """
        f = self.f
        events = {"cip": False, "replace": False, "restart": False}

        # --- restart detection ---------------------------------------------
        if running and not self.running_prev:
            dR = f["dRf_per_restart"]
            self.R_irr += dR * f["irreversible_fraction_restart"]
            self.R_irr_cumulative += dR * f["irreversible_fraction_restart"]
            self.R_rev += dR * (1.0 - f["irreversible_fraction_restart"])
            self.n_restart += 1
            events["restart"] = True
        self.running_prev = running

        # --- continuous accumulation ---------------------------------------
        if running:
            rate = fouling_rate_operating(T_C, load_fraction,
                                          biofouling_index, recovery, cfg=f)
        else:
            rate = fouling_rate_idle(T_C, biofouling_index, cfg=f)

        dR = float(rate) * dt_h
        self.R_irr += dR * f["irreversible_fraction"]
        self.R_irr_cumulative += dR * f["irreversible_fraction"]
        self.R_rev += dR * (1.0 - f["irreversible_fraction"])

        self.hours_total += dt_h
        self.hours_since_cip += dt_h
        self._hours_since_replace += dt_h

        # --- clean-in-place trigger ----------------------------------------
        # Requires BOTH a permeability trigger and a minimum elapsed interval,
        # which is how plants actually schedule cleaning and which prevents
        # threshold thrashing as irreversible fouling accumulates.
        pr = self.perm_ratio(T_C)
        if (pr < f["cip_trigger_perm_ratio"]
                and self.hours_since_cip >= f["cip_min_interval_h"]
                and self.cip_this_year < f["cip_max_per_year"]):
            self.R_rev *= (1.0 - f["cip_reversible_recovery"])
            self.n_cip += 1
            self.cip_this_year += 1
            self.hours_since_cip = 0.0
            self.downtime_h += f["cip_downtime_h"]
            events["cip"] = True
            pr = self.perm_ratio(T_C)

        # --- membrane replacement ------------------------------------------
        # Replacement is driven by IRREVERSIBLE loss: once CIP can no longer
        # restore enough permeability, the elements must be changed out.
        pr_after_ideal_cip = P.A_effective(T_C, self.R_irr) / P.A_clean(T_C)
        max_life_h = f["membrane_life_max_years"] * 8766.0
        if pr_after_ideal_cip < f["replace_perm_ratio"] or self._hours_since_replace >= max_life_h:
            self.R_rev = 0.0
            self.R_irr = 0.0
            self.n_replace += 1
            self.replace_intervals_h.append(self._hours_since_replace)
            self._hours_since_replace = 0.0
            events["replace"] = True

        return events

    def new_year(self):
        self.cip_this_year = 0

    def replacements_per_year(self, years, T_ref_C=30.0):
        """Continuous membrane consumption rate, replacements per year.

            rate = (R_irr_cumulative / years) / R*

        This is the quantity that should drive annualised membrane cost. It is
        independent of the simulation horizon and, unlike a replacement count,
        resolves differences in degradation that have not yet produced a
        discrete replacement event.
        """
        _, R_replace, _ = degradation_shadow_price(T_ref_C)
        if years <= 0 or R_replace <= 0:
            return 0.0
        return (self.R_irr_cumulative / years) / R_replace

    def projected_membrane_life_years(self, years, T_ref_C=30.0):
        """Membrane life implied by the cumulative irreversible accrual rate."""
        rpy = self.replacements_per_year(years, T_ref_C)
        if rpy <= 0:
            return float(self.f["membrane_life_max_years"])
        return min(1.0 / rpy, float(self.f["membrane_life_max_years"]))

    def mean_membrane_life_years(self):
        """Realised mean membrane life. If no replacement occurred within the
        simulation horizon, returns the censored lower bound."""
        if self.replace_intervals_h:
            return float(np.mean(self.replace_intervals_h)) / 8766.0
        return self._hours_since_replace / 8766.0


# ===========================================================================
# Shadow price of degradation  (used by the fouling-aware dispatch policy)
# ===========================================================================
def degradation_shadow_price(T_ref_C=30.0, capacity_m3_day=None):
    """Marginal cost of one unit of IRREVERSIBLE fouling resistance, USD.

    Derivation. Replacement is triggered when irreversible resistance reaches
    R_replace, the value at which normalised permeability equals
    replace_perm_ratio:

        A_eff/A_clean = p_rep
        => 1/(1/A_clean + R_replace) = p_rep / A_clean
        => R_replace = (1/p_rep - 1) / A_clean

    Spreading the membrane replacement cost over that resistance budget gives
    the shadow price

        lambda_irr = C_membrane_total / R_replace        [USD per unit R]

    This is the price the dispatcher must pay, in expectation, for every unit
    of irreversible fouling it causes. It is what converts "membrane life" from
    an engineering afterthought into a term in the objective function.
    """
    f = C.FOULING
    if capacity_m3_day is None:
        capacity_m3_day = C.TRAIN_CAPACITY_M3_DAY
    A_cl = P.A_clean(T_ref_C)
    R_replace = (1.0 / f["replace_perm_ratio"] - 1.0) / A_cl

    area = P.membrane_area_m2(capacity_m3_day)
    C_mem = area * C.ECON["membrane_capex_usd_m2"]
    return C_mem / R_replace, R_replace, C_mem


def calibration_report():
    lines = ["FOULING MODEL CALIBRATION", "=" * 72]

    lam, R_rep, C_mem = degradation_shadow_price()
    lines.append("Replacement resistance budget R_replace : %.4f m2*h*bar/L" % R_rep)
    lines.append("Membrane set cost per train             : %,.0f USD".replace(",", "") % C_mem)
    lines.append("Shadow price of irreversible fouling    : %.3e USD per unit R" % lam)

    lines.append("")
    lines.append("Hourly fouling rate, full load:")
    for T in (20.0, 25.0, 30.0, 35.0):
        r_op = fouling_rate_operating(T, 1.0)
        r_id = fouling_rate_idle(T)
        lines.append("   T=%4.1f C  operating %.3e   idle %.3e   (idle/op = %.2fx)"
                     % (T, r_op, r_id, r_id / r_op))

    lines.append("")
    lines.append("Part-load penalty on fouling rate (T=30 C):")
    base = fouling_rate_operating(30.0, 1.0)
    for L in (1.0, 0.8, 0.6, 0.4):
        r = fouling_rate_operating(30.0, L)
        lines.append("   load %.0f%%  rate %.3e  (%.2fx full load)" % (L * 100, r, r / base))

    lines.append("")
    lines.append("Time to CIP trigger under steady full-load operation:")
    for T, B in ((25.0, 1.0), (30.0, 3.0), (35.0, 3.0)):
        st = MembraneState()
        h = 0
        while st.perm_ratio(T) >= C.FOULING["cip_trigger_perm_ratio"] and h < 20000:
            st.step(1.0, T, True, 1.0, biofouling_index=B)
            h += 1
            if st.n_cip:
                break
        lines.append("   T=%4.1f C, biofouling index %.1f -> %5d h (%.1f months)"
                     % (T, B, h, h / 730.0))
    return "\n".join(lines)


if __name__ == "__main__":
    print(calibration_report())
