"""
verify_paper.py — Independent audit of the manuscript.

The manuscript's numbers are generated into 04_paper/numbers.tex by
make_numbers.py. That removes transcription error but not generation error, so
this script re-derives the load-bearing values by an INDEPENDENT route and
compares them against the macros actually defined. It also scans main.tex for
numeric literals that should have been macros, and for unresolved markers.

Checks performed
  A. Macro values vs independently recomputed physics
  B. Macro values vs the results CSVs, read separately from make_numbers.py
  C. Internal consistency of derived macros (ratios, percentages)
  D. Stray numeric literals left in main.tex
  E. Unresolved \verifyme / red '??' markers
  F. Every figure referenced by main.tex exists

Exit 0 = clean, 1 = issues found.
"""

import io
import os
import re
import sys

import numpy as np
import pandas as pd

import config as C
import physics as P
import fouling as F

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
PAPER = os.path.abspath(os.path.join(HERE, "..", "04_paper"))
TEX = os.path.join(PAPER, "main.tex")
NUM = os.path.join(PAPER, "numbers.tex")
FIGDIR = os.path.abspath(os.path.join(HERE, "..", "05_figures"))

issues = []
checks = [0]


def macros():
    """Parse numbers.tex into {name: string value}."""
    s = io.open(NUM, encoding="utf-8").read()
    out = {}
    for m in re.finditer(r"\\newcommand\{\\([A-Za-z]+)\}\{(.*)\}\s*$",
                         s, flags=re.M):
        out[m.group(1)] = m.group(2)
    return out


M = macros()


def num(name):
    """Macro value as float, or None."""
    v = M.get(name)
    if v is None:
        return None
    try:
        return float(v.replace(",", ""))
    except ValueError:
        return None


def chk(name, expected, tol_abs=None, tol_rel=0.011, label=None):
    """Compare macro `name` against an independently computed `expected`."""
    checks[0] += 1
    got = num(name)
    lab = label or name
    if got is None:
        issues.append("MISSING MACRO  %s (%s)" % (name, lab))
        return
    if expected is None:
        issues.append("NO SOURCE      %s" % lab)
        return
    ok = False
    if tol_abs is not None and abs(got - expected) <= tol_abs:
        ok = True
    if not ok and expected != 0 and abs(got - expected) / abs(expected) <= tol_rel:
        ok = True
    if not ok and tol_abs is None and abs(got - expected) <= 5e-4:
        ok = True
    if not ok:
        issues.append("MISMATCH       %-22s macro=%-12s recomputed=%.6g"
                      % (lab, M[name], expected))


def load(fn):
    p = os.path.join(RES, fn)
    return pd.read_csv(p) if os.path.exists(p) else None


# ===========================================================================
# A. physics recomputed independently of make_numbers.py
# ===========================================================================
chk("calPiOcean", float(P.osmotic_pressure_bar(35.0, 25.0)), tol_abs=0.01)
chk("calPiGulf", float(P.osmotic_pressure_bar(45.0, 35.0)), tol_abs=0.01)
chk("calSecOcean", float(P.sec_process_kWh_m3(35.0, 25.0, 0.45, 0.0)), tol_abs=0.01)
chk("calSecGulfSummer", float(P.sec_process_kWh_m3(45.0, 35.0, 0.40, 0.0)), tol_abs=0.01)
chk("calSecTotalGulf", float(P.sec_total_kWh_m3(45.0, 30.0, 0.40, 0.0, 1.0)), tol_abs=0.01)
chk("calPfeedGulf", float(P.required_feed_pressure_bar(45.0, 35.0, 0.40, 0.0)), tol_abs=0.1)
chk("calTcfCold", float(P.tcf(20.0)), tol_abs=0.001)
chk("calTcfHot", float(P.tcf(35.0)), tol_abs=0.001)
_, _R, _ = F.degradation_shadow_price()
chk("calRstar", float(_R), tol_abs=1e-4)
chk("cfgDemand", float(C.DEMAND_M3_DAY), tol_abs=1)

# independent recomputation of the Gulf penalty
_oc = float(P.sec_process_kWh_m3(35.0, 25.0, 0.45, 0.0))
_gu = float(P.sec_process_kWh_m3(45.0, 35.0, 0.40, 0.0))
chk("calGulfPenaltyPct", 100.0 * (_gu - _oc) / _oc, tol_abs=0.1)

# cycle tolerance identity
chk("cfgNtolDefault",
    float(_R / (C.FOULING["dRf_per_restart"]
                * C.FOULING["irreversible_fraction_restart"])), tol_abs=1)

# ===========================================================================
# B. macros vs the CSVs, read independently
# ===========================================================================
e2 = load("E2_policies.csv")
if e2 is not None:
    fx = e2[e2.design == "flex-enabled"].drop_duplicates("policy").set_index("policy")
    for pol, tag in (("baseload_grid", "Gb"), ("pv_baseload", "Pb"),
                     ("flex_blind", "Fb"), ("flex_aware", "Fa")):
        if pol not in fx.index:
            issues.append("E2 missing policy %s" % pol)
            continue
        r = fx.loc[pol]
        chk("pol%sLcow" % tag, float(r.lcow_usd_m3), tol_abs=0.001)
        chk("pol%sRe" % tag, 100 * float(r.re_fraction), tol_abs=0.06)
        chk("pol%sLife" % tag, float(r.membrane_life_yr), tol_abs=0.006)
        chk("pol%sMemCost" % tag, float(r.cost_membrane), tol_abs=0.001)
        chk("pol%sElecCost" % tag, float(r.cost_elec), tol_abs=0.001)
    # derived
    b, bl = fx.loc["pv_baseload"], fx.loc["flex_blind"]
    chk("blindLcowRisePct",
        100.0 * (float(bl.lcow_usd_m3) / float(b.lcow_usd_m3) - 1.0), tol_abs=0.6)
    chk("blindEnergySaving", float(b.cost_elec) - float(bl.cost_elec), tol_abs=0.001)
    chk("blindMemExtra", float(bl.cost_membrane) - float(b.cost_membrane),
        tol_abs=0.001)
else:
    issues.append("E2_policies.csv missing")

e4 = load("E4_cycle_frontier.csv")
if e4 is not None:
    d = e4.copy()
    d["N_tol"] = pd.to_numeric(d.N_tol, errors="coerce")
    fin = d[np.isfinite(d.N_tol)]
    base = fin[fin.label == "pv_baseload"].set_index("N_tol").lcow_usd_m3
    bl = fin[fin.label == "flex_blind"].set_index("N_tol").lcow_usd_m3
    aw = fin[fin.label == "flex_aware"].set_index("N_tol").lcow_usd_m3
    chk("frontMaxPenalty", float((bl - base).max()), tol_abs=0.002)
    chk("frontMaxBenefit", float((aw - base).min()), tol_abs=0.002)
    # asymmetry must equal penalty/|benefit|
    p, bnf = float((bl - base).max()), abs(float((aw - base).min()))
    if bnf > 0:
        chk("frontAsymmetry", p / bnf, tol_rel=0.03)
    for nt, tag in ((250, "Na"), (500, "Nb"), (1000, "Nc"), (2000, "Nd"),
                    (4000, "Ne"), (8000, "Nf")):
        chk("front%sBase" % tag, float(base.get(nt, np.nan)), tol_abs=0.001)
        chk("front%sBlind" % tag, float(bl.get(nt, np.nan)), tol_abs=0.001)
        chk("front%sAware" % tag, float(aw.get(nt, np.nan)), tol_abs=0.001)
    # critical tolerance must lie inside the swept range and be positive
    nc = num("frontNtolCrit")
    if nc is not None and not (250 <= nc <= 8000):
        issues.append("frontNtolCrit %.0f outside the swept range 250-8000" % nc)
    ncy = num("frontNtolCritYears")
    if nc is not None and ncy is not None and abs(ncy - nc / 360.0) > 0.15:
        issues.append("frontNtolCritYears inconsistent with frontNtolCrit/360")
else:
    issues.append("E4_cycle_frontier.csv missing")

e3 = load("E3_design_space.csv")
if e3 is not None:
    s = e3[(e3.policy == "pv_baseload") & (e3.ro_oversize == 1.09)
           & (e3.unmet_frac < 0.02)].sort_values("pv_frac_parity")
    b0 = s[s.pv_frac_parity == 0.0].iloc[0]
    for pf, tag in ((0.0, "Zero"), (0.3, "Low"), (0.6, "Mid"), (1.0, "Parity")):
        t = s[np.isclose(s.pv_frac_parity, pf)]
        if t.empty:
            continue
        r = t.iloc[0]
        chk("sat%sRe" % tag, 100 * float(r.re_fraction), tol_abs=0.06)
        chk("sat%sLcow" % tag, float(r.lcow_usd_m3), tol_abs=0.001)
        if pf > 0:
            dl = float(r.lcow_usd_m3) - float(b0.lcow_usd_m3)
            dco2 = (float(b0.co2_t_yr) - float(r.co2_t_yr)) / float(r.ann_delivered_m3)
            chk("sat%sCarbon" % tag, dl / dco2, tol_rel=0.02)
else:
    issues.append("E3_design_space.csv missing")

# ===========================================================================
# C. internal consistency of the parameter census
# ===========================================================================
a, t = num("paramAsm"), num("paramTotal")
p = num("paramAsmPct")
if a and t and p and abs(100.0 * a / t - p) > 0.6:
    issues.append("paramAsmPct inconsistent with paramAsm/paramTotal")
checks[0] += 1

# ===========================================================================
# G. verification-pass macros, recomputed independently
# ===========================================================================
import math as _m
_pif_v = float(P.osmotic_pressure_bar(35.0, 25.0))
_pic_v = float(P.osmotic_pressure_bar(P.concentrate_salinity(35.0, 0.5), 25.0))
chk("thermoLeastWork", _pif_v * _m.log(2.0) / 0.5 * P.BAR_M3_TO_KWH, tol_abs=0.006)
chk("thermoSingleStage", _pic_v * P.BAR_M3_TO_KWH, tol_abs=0.006)
_lw, _ss = num("thermoLeastWork"), num("thermoSingleStage")
checks[0] += 1
if _lw is not None and _ss is not None:
    if not (_lw < _ss < float(P.sec_process_kWh_m3(35.0, 25.0, 0.45, 0.0))):
        issues.append("thermodynamic ordering violated: least work < "
                      "single-stage limit < simulated process SEC")
_EF0_v = float(C.ECON["grid_co2_kg_kWh"])
for _tag in ("Low", "Mid", "Parity"):
    _base_c = num("sat%sCarbon" % _tag)
    _dirty = num("sat%sCarbonDirty" % _tag)
    _clean = num("sat%sCarbonClean" % _tag)
    checks[0] += 1
    if None in (_base_c, _dirty, _clean):
        issues.append("carbon band macros missing for %s" % _tag)
        continue
    if not (_dirty < _base_c < _clean):
        issues.append("carbon band not ordered for %s" % _tag)
    if (abs(_dirty - _base_c * _EF0_v / 0.55) > 1.5
            or abs(_clean - _base_c * _EF0_v / 0.27) > 1.5):
        issues.append("carbon band for %s does not scale with EF" % _tag)

# ===========================================================================
# D/E/F. manuscript scans
# ===========================================================================
tex = io.open(TEX, encoding="utf-8").read()
# strip LaTeX comments so the scans do not match documentation of the
# markers themselves
tex_nc = re.sub(r"(?m)^%.*$", "", tex)
tex_nc = re.sub(r"(?<!\\)%.*", "", tex_nc)

todos = []
for m in re.finditer(r"\\verifyme\{([^}]*)\}", tex_nc):
    todos.append(m.group(1)[:90].replace("\n", " "))
for m in re.finditer(r"\\pending\{([^}]*)\}", tex_nc):
    issues.append("UNRESOLVED \\pending: %s" % m.group(1)[:70].replace("\n", " "))
for name, val in M.items():
    if "??" in val:
        issues.append("UNRESOLVED MACRO %s rendered as '??'" % name)
checks[0] += 3

# stray result-like literals in prose (exclude the preamble and tables)
body = tex_nc[tex_nc.find(r"\section{Results}"):]
body = re.sub(r"\\begin\{tabular\}.*?\\end\{tabular\}", "", body, flags=re.S)
strays = set()
for m in re.finditer(r"\\SI\{([0-9]+\.[0-9]+)\}", body):
    strays.add(m.group(1))
ALLOWED = {"1.09", "1.60", "3.9", "1.6", "0.040", "27.5", "12.0", "0.5"}
strays -= ALLOWED
if strays:
    issues.append("HARDCODED numerics in Results prose: %s"
                  % ", ".join(sorted(strays)))
checks[0] += 1

# figures referenced must exist
for m in re.finditer(r"includegraphics\[[^\]]*\]\{([^}]+)\}", tex):
    rel = m.group(1)
    path = os.path.abspath(os.path.join(PAPER, rel))
    checks[0] += 1
    if not os.path.exists(path):
        issues.append("MISSING FIGURE %s" % rel)


# ===========================================================================
def main():
    print("=" * 74)
    print("MANUSCRIPT AUDIT (independent recomputation)")
    print("=" * 74)
    print("%d macros defined, %d checks run\n" % (len(M), checks[0]))
    if issues:
        print("%d BLOCKING ISSUE(S):" % len(issues))
        for i in issues:
            print("   %s" % i)
    else:
        print("No blocking issues. Every audited macro matches an independent")
        print("recomputation, and every referenced figure exists.")
    if todos:
        print("\n%d ITEM(S) REQUIRING HUMAN INPUT before submission:" % len(todos))
        for t in todos:
            print("   - %s" % t)
    return 1 if issues else 0


if __name__ == "__main__":
    sys.exit(main())
