"""
make_figures.py — Publication figures from the saved experiment results.

Reads only results/*.csv, so figures can be regenerated without re-simulating.
Outputs 300 dpi PNG plus vector PDF into ../05_figures/.

Style: greyscale-safe, colourblind-safe (Okabe-Ito), no chartjunk, no
gratuitous colour. Every axis labelled with units.
"""

import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.ticker import MaxNLocator

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
FIG = os.path.abspath(os.path.join(HERE, "..", "05_figures"))
os.makedirs(FIG, exist_ok=True)

# Okabe-Ito colourblind-safe palette
CB = dict(blue="#0072B2", orange="#E69F00", green="#009E73", red="#D55E00",
          purple="#CC79A7", sky="#56B4E9", yellow="#F0E442", black="#000000")

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["DejaVu Serif", "Times New Roman"],
    "font.size": 9,
    "axes.titlesize": 10,
    "axes.labelsize": 9,
    "legend.fontsize": 8,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.alpha": 0.25,
    "grid.linewidth": 0.5,
    "figure.dpi": 120,
    "savefig.bbox": "tight",
})


def save(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(FIG, "%s.%s" % (name, ext)), dpi=300)
    plt.close(fig)
    print("  wrote %s.png / .pdf" % name)


def have(fn):
    return os.path.exists(os.path.join(RES, fn))


# ===========================================================================
# Fig 1 — the Gulf seasonal tension
# ===========================================================================
def fig1_seasonal():
    if not have("E1_seasonal.csv"):
        return
    d = pd.read_csv(os.path.join(RES, "E1_seasonal.csv"))
    fig, ax = plt.subplots(figsize=(6.4, 3.2))

    ax.plot(d.doy, d.sec_kWh_m3, color=CB["blue"], lw=1.8,
            label="Specific energy consumption")
    ax.set_xlabel("Day of year")
    ax.set_ylabel("SEC (kWh m$^{-3}$)", color=CB["blue"])
    ax.tick_params(axis="y", labelcolor=CB["blue"])
    ax.set_xlim(0, 366)

    ax2 = ax.twinx()
    ax2.spines["right"].set_visible(True)
    ax2.plot(d.doy, d.foul_rate_op * 1e4, color=CB["red"], lw=1.8, ls="--",
             label="Biofouling rate (operating)")
    ax2.plot(d.doy, d.foul_rate_idle * 1e4, color=CB["orange"], lw=1.4, ls=":",
             label="Biofouling rate (idle)")
    ax2.set_ylabel(r"Fouling rate ($10^{-4}$ m$^2$ h bar L$^{-1}$ h$^{-1}$)",
                   color=CB["red"])
    ax2.tick_params(axis="y", labelcolor=CB["red"])
    ax2.grid(False)

    # mark the summer window where energy is cheapest but fouling fastest
    i_lo = int(d.sec_kWh_m3.idxmin())
    ax.axvspan(d.doy[i_lo] - 45, d.doy[i_lo] + 45, color=CB["yellow"],
               alpha=0.18, zorder=0)
    ax.annotate("summer: lowest SEC,\nfastest fouling",
                xy=(d.doy[i_lo], d.sec_kWh_m3[i_lo]),
                xytext=(0.03, 0.42), textcoords="axes fraction",
                fontsize=8, arrowprops=dict(arrowstyle="->", lw=0.7,
                                            color="0.35"))

    # the title lives in the LaTeX caption; the legend sits above the axes
    # so it never covers the curves
    h1, l1 = ax.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc="lower center",
              bbox_to_anchor=(0.5, 1.01), frameon=False, ncol=3,
              fontsize=7.5)
    save(fig, "fig1_seasonal_tension")


# ===========================================================================
# Fig 2 — LCOW decomposition by policy
# ===========================================================================
def fig2_policies():
    if not have("E2_policies.csv"):
        return
    d = pd.read_csv(os.path.join(RES, "E2_policies.csv"))
    d = d[d.design == "flex-enabled"] if "design" in d else d
    if d.empty:
        return

    order = ["baseload_grid", "pv_baseload", "flex_blind", "flex_aware"]
    nice = {"baseload_grid": "Grid\nbaseload",
            "pv_baseload": "PV +\nbaseload",
            "flex_blind": "PV + flex\n(blind)",
            "flex_aware": "PV + flex\n(aware)"}
    d = d[d.policy.isin(order)].drop_duplicates("policy").set_index("policy")
    d = d.reindex([o for o in order if o in d.index])

    comps = [("cost_capital", "Capital", CB["blue"]),
             ("cost_elec", "Electricity", CB["orange"]),
             ("cost_membrane", "Membrane replacement", CB["red"]),
             ("cost_cip", "Cleaning (CIP)", CB["purple"]),
             ("cost_pv_clean", "PV washing", CB["sky"]),
             ("cost_fixed", "Fixed O&M", CB["green"])]

    fig, (ax, ax2) = plt.subplots(1, 2, figsize=(7.2, 3.4),
                                  gridspec_kw={"width_ratios": [1.55, 1]})
    x = np.arange(len(d))
    bottom = np.zeros(len(d))
    for key, lab, col in comps:
        v = d[key].to_numpy(dtype=float)
        ax.bar(x, v, 0.62, bottom=bottom, label=lab, color=col,
               edgecolor="white", lw=0.4)
        bottom += v
    ax.plot(x, d.lcow_usd_m3, "k_", ms=22, mew=1.8, label="Net LCOW")
    for xi, v in zip(x, d.lcow_usd_m3):
        ax.annotate("%.3f" % v, (xi, v), xytext=(0, 7),
                    textcoords="offset points", ha="center", fontsize=8,
                    fontweight="bold")
    ax.set_xticks(x)
    ax.set_xticklabels([nice[i] for i in d.index])
    ax.set_ylabel("Levelized cost of water (USD m$^{-3}$)")
    ax.set_title("(a) Cost decomposition")
    # Legend placed in its own strip below the axis: inside the axes it
    # collides with the value annotation on the tall centre bar.
    ax.legend(frameon=False, fontsize=7, loc="upper center",
              bbox_to_anchor=(0.5, -0.16), ncol=3)
    ax.set_ylim(0, bottom.max() * 1.12)

    w = 0.38
    ax2.bar(x - w / 2, d.membrane_life_yr, w, color=CB["red"],
            label="Membrane life (yr)")
    ax2.set_ylabel("Membrane life (years)", color=CB["red"])
    ax2.tick_params(axis="y", labelcolor=CB["red"])
    ax2b = ax2.twinx()
    ax2b.spines["right"].set_visible(True)
    ax2b.bar(x + w / 2, 100 * d.re_fraction, w, color=CB["green"],
             label="Renewable fraction (%)")
    ax2b.set_ylabel("Renewable energy fraction (%)", color=CB["green"])
    ax2b.tick_params(axis="y", labelcolor=CB["green"])
    ax2b.grid(False)
    short = {"baseload_grid": "Grid", "pv_baseload": "PV+base",
             "flex_blind": "Flex\nblind", "flex_aware": "Flex\naware"}
    ax2.set_xticks(x)
    ax2.set_xticklabels([short[i] for i in d.index], fontsize=8)
    ax2.set_title("(b) The trade-off")
    save(fig, "fig2_policy_decomposition")


# ===========================================================================
# Fig 3 — THE CENTRAL FIGURE: cycle-tolerance frontier
# ===========================================================================
def fig3_frontier():
    if not have("E4_cycle_frontier.csv"):
        return
    d = pd.read_csv(os.path.join(RES, "E4_cycle_frontier.csv"))
    d["N_tol"] = pd.to_numeric(d.N_tol, errors="coerce")
    finite = d[np.isfinite(d.N_tol)]

    base = finite[finite.label == "pv_baseload"].sort_values("N_tol")
    bl = finite[finite.label == "flex_blind"].sort_values("N_tol")
    aw = finite[finite.label == "flex_aware"].sort_values("N_tol")

    fig, (ax, ax2) = plt.subplots(2, 1, figsize=(6.2, 5.2), sharex=True,
                                  gridspec_kw={"height_ratios": [1.45, 1]})

    ax.plot(base.N_tol, base.lcow_usd_m3, color=CB["black"], lw=1.8, marker="o",
            ms=4, label="PV + steady baseload (current practice)")
    ax.plot(bl.N_tol, bl.lcow_usd_m3, color=CB["red"], lw=1.8, marker="s",
            ms=4, ls="--", label="PV + flexible, degradation-blind")
    ax.plot(aw.N_tol, aw.lcow_usd_m3, color=CB["blue"], lw=1.8, marker="^",
            ms=4, label="PV + flexible, degradation-aware")
    ax.set_xscale("log")
    ax.set_ylabel("Levelized cost of water (USD m$^{-3}$)")
    ax.legend(frameon=False, loc="upper right")
    ax.set_title("Cycle-tolerance frontier for flexible renewable-powered "
                 "Gulf SWRO")

    # Delta panel. BOTH deltas are plotted on a symmetric-log axis, because
    # the headline of the paper is the ASYMMETRY between them: the upside of
    # correctly-priced flexibility is of order 0.02 USD/m3, whereas the cost of
    # pricing it blind is of order 0.4 USD/m3. Splitting those across two
    # linear panels hides the very comparison the reader needs.
    m = aw[["N_tol", "lcow_usd_m3"]].merge(
        base[["N_tol", "lcow_usd_m3"]], on="N_tol", suffixes=("_aw", "_base"))
    m["delta"] = m.lcow_usd_m3_aw - m.lcow_usd_m3_base
    mb = bl[["N_tol", "lcow_usd_m3"]].merge(
        base[["N_tol", "lcow_usd_m3"]], on="N_tol", suffixes=("_bl", "_base"))
    mb["delta"] = mb.lcow_usd_m3_bl - mb.lcow_usd_m3_base

    ax2.axhline(0, color="0.3", lw=1.0)
    ax2.plot(mb.N_tol, mb.delta, color=CB["red"], lw=1.8, marker="s", ms=4,
             ls="--", label="degradation-blind (penalty)")
    ax2.plot(m.N_tol, m.delta, color=CB["blue"], lw=1.8, marker="^", ms=4,
             label="degradation-aware (benefit)")
    ax2.fill_between(mb.N_tol, mb.delta, 0, color=CB["red"], alpha=0.13)
    ax2.fill_between(m.N_tol, m.delta, 0, where=(m.delta <= 0),
                     color=CB["green"], alpha=0.22)
    ax2.set_xscale("log")
    ax2.set_yscale("symlog", linthresh=0.02)
    ax2.set_xlabel(r"Cycle tolerance $N_{\mathrm{tol}}$ "
                   "(start/stop cycles before membrane replacement)")
    ax2.set_ylabel(r"$\Delta$LCOW vs baseload" "\n(USD m$^{-3}$, symlog)")
    ax2.legend(frameon=False, fontsize=7.5, loc="upper right")

    # crossover
    cross = None
    dv = m.delta.to_numpy()
    nv = m.N_tol.to_numpy()
    for i in range(len(dv) - 1):
        if dv[i] > 0 >= dv[i + 1]:
            f = dv[i] / (dv[i] - dv[i + 1])
            cross = 10 ** (np.log10(nv[i]) + f * (np.log10(nv[i + 1])
                                                  - np.log10(nv[i])))
            break
    if cross:
        for a in (ax, ax2):
            a.axvline(cross, color=CB["purple"], lw=1.2, ls="-.")
        # Label sits in the upper panel, right-aligned just left of the
        # crossover line: the band is below the legend and above the blind
        # curve there, whereas in the lower panel it overlapped data markers.
        ylo, yhi = ax.get_ylim()
        y_base = np.interp(np.log10(cross), np.log10(base.N_tol),
                           base.lcow_usd_m3)
        ax.annotate(r"$N_{\mathrm{tol}}^{*}\approx%.0f$ cycles" % cross
                    + "\n(%.1f yr of daily cycling)" % (cross / 360.0),
                    xy=(cross, y_base),
                    xytext=(cross / 1.1, ylo + 0.42 * (yhi - ylo)),
                    ha="right", va="center", fontsize=8, color=CB["purple"],
                    arrowprops=dict(arrowstyle="->", lw=0.8,
                                    color=CB["purple"]))
    ax2.text(0.03, 0.30, "flexibility uneconomic", transform=ax2.transAxes,
             fontsize=8, color=CB["red"])
    ax2.text(0.66, 0.30, "flexibility pays", transform=ax2.transAxes,
             fontsize=8, color=CB["green"])

    # Membrane replacement band: operating SWRO plants replace membranes after
    # 2-5 yr (Avlonitis et al. 2003), i.e. 720-1800 daily cycles. The label sits
    # in the lower panel, centred on the band in log space, between the blind
    # penalty curve and the zero line; in the upper panel it crossed the blind
    # curve and the legend.
    for a in (ax, ax2):
        a.axvspan(2 * 360, 5 * 360, color="0.5", alpha=0.13, zorder=0)
    ax2.text(np.sqrt(2 * 360 * 5 * 360), 0.45,
             "membrane\nreplacement\n(2\u20135 yr)",
             transform=ax2.get_xaxis_transform(), fontsize=7, color="0.35",
             ha="center", va="center", linespacing=1.1)
    save(fig, "fig3_cycle_tolerance_frontier")
    return cross


# ===========================================================================
# Fig 4 — 2D frontier heatmap
# ===========================================================================
def fig4_frontier_2d():
    if not have("E5_frontier_2d.csv"):
        return
    d = pd.read_csv(os.path.join(RES, "E5_frontier_2d.csv"))
    d["N_tol"] = pd.to_numeric(d.N_tol, errors="coerce")
    d = d[np.isfinite(d.N_tol)]
    if d.empty:
        return
    piv = d.pivot_table(index="N_tol", columns="biofouling_index",
                        values="delta_lcow")

    fig, ax = plt.subplots(figsize=(5.6, 3.8))
    vmax = np.nanmax(np.abs(piv.to_numpy()))
    im = ax.pcolormesh(np.arange(len(piv.columns) + 1),
                       np.arange(len(piv.index) + 1),
                       piv.to_numpy(), cmap="RdYlGn_r",
                       vmin=-vmax, vmax=vmax, edgecolors="white", lw=0.6)
    for i in range(len(piv.index)):
        for j in range(len(piv.columns)):
            v = piv.to_numpy()[i, j]
            if np.isfinite(v):
                ax.text(j + 0.5, i + 0.5, "%+.2f" % v, ha="center",
                        va="center", fontsize=7.5,
                        color="white" if abs(v) > 0.6 * vmax else "black")
    ax.set_xticks(np.arange(len(piv.columns)) + 0.5)
    ax.set_xticklabels(["%.1f" % c for c in piv.columns])
    ax.set_yticks(np.arange(len(piv.index)) + 0.5)
    ax.set_yticklabels(["%.0f" % i for i in piv.index])
    ax.set_xlabel("Feed biofouling index $B$ (1.0 = open ocean)")
    ax.set_ylabel(r"Cycle tolerance $N_{\mathrm{tol}}$")
    ax.set_title(r"$\Delta$LCOW of flexible vs baseload operation "
                 "(USD m$^{-3}$)")
    ax.grid(False)
    cb = fig.colorbar(im, ax=ax, pad=0.02)
    cb.set_label(r"$\Delta$LCOW (USD m$^{-3}$); green = flexibility pays")
    save(fig, "fig4_frontier_2d")


# ===========================================================================
# Fig 5 — tariff-spread frontier
# ===========================================================================
def fig5_tariff():
    if not have("E6_tariff_frontier.csv"):
        return
    d = pd.read_csv(os.path.join(RES, "E6_tariff_frontier.csv"))
    d["N_tol"] = pd.to_numeric(d.N_tol, errors="coerce")
    fig, ax = plt.subplots(figsize=(5.8, 3.4))
    cols = [CB["red"], CB["orange"], CB["purple"], CB["blue"], CB["green"]]
    for k, (nt, g) in enumerate(d.groupby("N_tol", dropna=False)):
        g = g.sort_values("tariff_spread")
        lab = r"$N_{\mathrm{tol}}=\infty$" if not np.isfinite(nt) \
            else r"$N_{\mathrm{tol}}=%.0f$" % nt
        ax.plot(g.tariff_spread, g.delta_lcow, marker="o", ms=4, lw=1.6,
                color=cols[k % len(cols)], label=lab)
    ax.axhline(0, color="0.3", lw=1.0)
    ax.set_xlabel("Time-of-use tariff spread (fraction of base price)")
    ax.set_ylabel(r"$\Delta$LCOW vs baseload (USD m$^{-3}$)")
    ax.set_title("Tariff spread cannot rescue flexibility at low cycle "
                 "tolerance")
    ax.legend(frameon=False, ncol=2, fontsize=7.5)
    save(fig, "fig5_tariff_frontier")


# ===========================================================================
# Fig 6 — sensitivity tornado
# ===========================================================================
def fig6_sensitivity():
    if not have("E8_sensitivity.csv"):
        return
    d = pd.read_csv(os.path.join(RES, "E8_sensitivity.csv"))
    d = d[d.label == "pv_baseload"]
    if d.empty:
        return
    rows = []
    for p, g in d.groupby("param"):
        b = g[g.is_base]
        base = float(b.lcow_usd_m3.iloc[0]) if not b.empty \
            else float(g.lcow_usd_m3.median())
        rows.append(dict(param=p, lo=g.lcow_usd_m3.min() - base,
                         hi=g.lcow_usd_m3.max() - base, base=base,
                         span=g.lcow_usd_m3.max() - g.lcow_usd_m3.min()))
    t = pd.DataFrame(rows).sort_values("span")

    pretty = {
        "FOULING.alpha_shear": "Shear-removal exponent",
        "FOULING.idle_multiplier": "Idle fouling multiplier",
        "FOULING.dRf_per_restart": "Per-restart degradation",
        "SEAWATER.biofouling_index": "Feed biofouling index",
        "SEAWATER.salinity_g_L": "Feed salinity",
        "ECON.elec_price_usd_kWh": "Electricity price",
        "ECON.pv_capex_usd_kWp": "PV capital cost",
        "ECON.batt_capex_usd_kWh": "Battery capital cost",
    }
    labels = [pretty.get(p, p) for p in t.param]
    y = np.arange(len(t))
    fig, ax = plt.subplots(figsize=(6.0, 3.4))
    ax.barh(y, t.hi, color=CB["red"], alpha=0.85, label="parameter high")
    ax.barh(y, t.lo, color=CB["blue"], alpha=0.85, label="parameter low")
    ax.axvline(0, color="0.2", lw=1.0)
    ax.set_yticks(y)
    ax.set_yticklabels(labels)
    ax.set_xlabel(r"Change in LCOW vs baseline (USD m$^{-3}$)")
    ax.set_title("One-at-a-time sensitivity of baseline LCOW")
    ax.legend(frameon=False, loc="lower right")
    save(fig, "fig6_sensitivity_tornado")


# ===========================================================================
# Fig 7 — design space
# ===========================================================================
def fig7_design_space():
    if not have("E3_design_space.csv"):
        return
    d = pd.read_csv(os.path.join(RES, "E3_design_space.csv"))
    d = d[d.unmet_frac < 0.02]
    if d.empty:
        return
    pols = [("pv_baseload", "PV + baseload"),
            ("flex_blind", "Flexible, blind"),
            ("flex_aware", "Flexible, aware")]
    fig, axes = plt.subplots(1, 3, figsize=(7.6, 2.9), sharey=True)
    vmin = d.lcow_usd_m3.quantile(0.02)
    vmax = d.lcow_usd_m3.quantile(0.98)
    im = None
    for ax, (p, lab) in zip(axes, pols):
        s = d[d.policy == p]
        if s.empty:
            ax.set_visible(False)
            continue
        piv = s.pivot_table(index="ro_oversize", columns="pv_frac_parity",
                            values="lcow_usd_m3")
        im = ax.pcolormesh(piv.columns, piv.index, piv.to_numpy(),
                           cmap="viridis_r", vmin=vmin, vmax=vmax,
                           shading="nearest")
        b = s.loc[s.lcow_usd_m3.idxmin()]
        ax.plot(b.pv_frac_parity, b.ro_oversize, "*", color="white", ms=15,
                mec="black", mew=0.8)
        ax.set_title(lab)
        ax.set_xlabel("PV capacity (x energy parity)")
        ax.grid(False)
        ax.xaxis.set_major_locator(MaxNLocator(4))
    axes[0].set_ylabel("RO oversize factor")
    if im is not None:
        cb = fig.colorbar(im, ax=axes, pad=0.02)
        cb.set_label("LCOW (USD m$^{-3}$)")
    save(fig, "fig7_design_space")


if __name__ == "__main__":
    print("Generating figures into %s" % FIG)
    fig1_seasonal()
    fig2_policies()
    cross = fig3_frontier()
    fig4_frontier_2d()
    fig5_tariff()
    fig6_sensitivity()
    fig7_design_space()
    if cross:
        print("\nCritical cycle tolerance N_tol* = %.0f cycles (%.1f yr daily)"
              % (cross, cross / 360.0))
    print("Done.")
