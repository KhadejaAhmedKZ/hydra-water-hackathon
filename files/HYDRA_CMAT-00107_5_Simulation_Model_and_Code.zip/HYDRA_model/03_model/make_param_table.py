"""
make_param_table.py — Emits the parameter/provenance appendix from config.py.

The appendix is generated rather than hand-written so that it can never drift
from the values actually used in the simulations. Provenance tags are parsed
from the inline comments in config.py.
"""

import io
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.abspath(os.path.join(HERE, "..", "04_paper", "param_table.tex"))

TAGDESC = {
    "LIT": "published literature",
    "IND": "industry disclosure",
    "DER": "derived / calibrated",
    "ASM": "assumption of this study",
    "ENG": "standard engineering value, not individually sourced",
    "DATA": "measured reanalysis data",
}

SECTION_TITLES = {
    "SITE": "Site",
    "SEAWATER": "Gulf seawater",
    "RO": "RO process",
    "FOULING": "Fouling and degradation",
    "PV": "Photovoltaics",
    "STORAGE": "Storage",
    "ECON": "Economics",
    "DEMAND": "Water demand",
}

PRETTY = {
    "salinity_g_L": r"Feed salinity $S_f$ (g\,L$^{-1}$)",
    "sst_min_C": r"Min sea-surface temperature ($^\circ$C)",
    "sst_max_C": r"Max sea-surface temperature ($^\circ$C)",
    "osmotic_coeff": r"Osmotic coefficient $\phi$",
    "biofouling_index": r"Feed biofouling index $B$",
    "recovery": r"Recovery ratio $r$",
    "A_clean_25": r"Clean permeability $A_{25}$ (L\,m$^{-2}$h$^{-1}$bar$^{-1}$)",
    "Ke_tcf": r"TCF constant $K_e$ (K)",
    "design_flux_LMH": r"Design flux $J$ (L\,m$^{-2}$h$^{-1}$)",
    "salt_rejection": r"Salt rejection $\mathcal{R}$",
    "eta_hpp": r"HP pump efficiency $\eta_{\mathrm{HPP}}$",
    "eta_erd": r"ERD efficiency $\eta_{\mathrm{ERD}}$",
    "dp_friction_bar": r"Feed-channel $\Delta P$ (bar)",
    "sec_auxiliary_kWh_m3": r"Auxiliary SEC (kWh\,m$^{-3}$)",
    "load_min": r"Minimum stable load $L_{\min}$",
    "k_bio_ref": r"Biofouling rate coefficient $k_{\mathrm{bio}}$",
    "Q10": r"Growth temperature sensitivity $Q_{10}$",
    "alpha_shear": r"Shear-removal exponent $\alpha$",
    "idle_multiplier": r"Stagnation multiplier $m_{\mathrm{idle}}$",
    "dRf_per_restart": r"Per-restart increment $\delta R$",
    "irreversible_fraction": r"Irreversible fraction $f_{\mathrm{irr}}$",
    "irreversible_fraction_restart":
        r"Irreversible fraction, restart $f_{\mathrm{irr}}^{\mathrm{start}}$",
    "k_scale_ref": r"Scaling coefficient $k_{\mathrm{scale}}$",
    "cip_trigger_perm_ratio": r"CIP trigger (normalised permeability)",
    "cip_reversible_recovery": r"CIP recovery fraction",
    "cip_min_interval_h": r"Minimum CIP interval (h)",
    "cip_cost_usd_per_train": r"CIP cost (USD)",
    "replace_perm_ratio": r"Replacement threshold $p_{\mathrm{rep}}$",
    "membrane_life_max_years": r"Membrane life ceiling (yr)",
    "eta_stc": r"Module efficiency at STC",
    "temp_coeff_pmax": r"Power temperature coefficient (K$^{-1}$)",
    "noct_C": r"NOCT ($^\circ$C)",
    "dc_ac_ratio": r"DC/AC ratio",
    "soiling_rate_per_day_per_AOD": r"Soiling rate per unit AOD per day",
    "soiling_max": r"Soiling loss ceiling $\ell_{\max}$",
    "clean_interval_days": r"PV wash interval (d)",
    "clean_cost_usd_per_m2": r"PV wash cost (USD\,m$^{-2}$)",
    "discount_rate": r"Real discount rate $i$",
    "plant_life_years": r"Economic life $n$ (yr)",
    "elec_price_usd_kWh": r"Grid electricity (USD\,kWh$^{-1}$)",
    "elec_export_usd_kWh": r"PV export value (USD\,kWh$^{-1}$)",
    "tariff_spread": r"Time-of-use spread",
    "grid_co2_kg_kWh": r"Grid emission factor (kg\,kWh$^{-1}$)",
    "ro_capex_usd_m3_day": r"RO CAPEX (USD per m$^3$d$^{-1}$)",
    "pv_capex_usd_kWp": r"PV CAPEX (USD\,kW$_p^{-1}$)",
    "batt_capex_usd_kWh": r"Battery CAPEX (USD\,kWh$^{-1}$)",
    "tank_capex_usd_m3": r"Tank CAPEX (USD\,m$^{-3}$)",
    "membrane_capex_usd_m2": r"Membrane cost (USD\,m$^{-2}$)",
    "opex_fixed_usd_m3": r"Fixed O\&M (USD\,m$^{-3}$)",
    "batt_eta_rt": r"Battery round-trip efficiency",
    "annual_mean_fraction": r"Mean utilisation of nameplate",
    "summer_peak_amplitude": r"Seasonal demand amplitude",
}

SKIP = {"name", "lat", "lon", "tz", "salinity_range", "biofouling_index_range",
        "recovery_range", "elec_price_range", "opex_fixed_range",
        "sst_peak_doy", "peak_doy", "load_max", "cip_downtime_h",
        "cip_max_per_year", "membrane_life_min_years", "other_losses",
        "inverter_eta", "batt_dod", "batt_cycle_life", "tank_loss_per_day",
        "tank_max_hours", "diurnal_amplitude", "min_daily_delivery_frac",
        "T_ref_C", "tariff_solar_hours", "tariff_peak_hours",
        "pv_share_contracted", "pv_share_target", "capacity_m3_day",
        "pv_installed_MWp", "sst_mean_C"}


def parse_tags():
    """Extract {section: {key: (value_str, tag)}} from config.py comments."""
    src = io.open(os.path.join(HERE, "config.py"), encoding="utf-8").read()
    out, section = {}, None
    for line in src.splitlines():
        m = re.match(r"^([A-Z_]+)\s*=\s*dict\(", line)
        if m:
            section = m.group(1)
            out[section] = {}
            continue
        if line.startswith(")"):
            section = None
        if section is None:
            continue
        m = re.match(r"\s*([a-zA-Z_0-9]+)\s*=\s*([^,#]+),?\s*(#\s*\[(\w+)\].*)?$",
                     line)
        if m:
            key, val, tag = m.group(1), m.group(2).strip(), m.group(4)
            out[section][key] = (val, tag or "")
    return out


def fmt(v):
    v = v.strip().rstrip(",")
    try:
        f = float(v.replace("_", ""))
        if f == int(f) and abs(f) < 1e6:
            return "%d" % int(f)
        if abs(f) < 1e-3:
            return "%.1e" % f
        return ("%.4f" % f).rstrip("0").rstrip(".")
    except ValueError:
        return v.replace("_", r"\_")


def main():
    tags = parse_tags()
    L = []
    L.append(r"% AUTO-GENERATED by make_param_table.py -- do not edit by hand")
    L.append(r"\begin{table*}[t]")
    L.append(r"\centering\footnotesize")
    L.append(r"\caption{Model parameters and their provenance. "
             r"\textbf{LIT} published literature, \textbf{IND} industry "
             r"disclosure, \textbf{DER} derived or calibrated, \textbf{ASM} "
             r"assumption of this study, \textbf{ENG} standard engineering value "
             r"not individually sourced, \textbf{DATA} measured reanalysis. "
             r"Every \textbf{ASM} entry is swept in the sensitivity analysis; "
             r"the three governing the flexibility conclusion are "
             r"$\alpha$, $m_{\mathrm{idle}}$ and $\delta R$.}")
    L.append(r"\label{tab:params}")
    L.append(r"\begin{tabular}{llrp{0.28\textwidth}}")
    L.append(r"\toprule")
    L.append(r"\textbf{Group} & \textbf{Parameter} & \textbf{Value} "
             r"& \textbf{Provenance} \\")
    L.append(r"\midrule")

    n = 0
    for sec in ["SEAWATER", "RO", "FOULING", "PV", "STORAGE", "ECON", "DEMAND"]:
        if sec not in tags:
            continue
        first = True
        for key, (val, tag) in tags[sec].items():
            if key in SKIP or not tag:
                continue
            label = PRETTY.get(key, key.replace("_", r"\_"))
            grp = SECTION_TITLES.get(sec, sec) if first else ""
            L.append(r"%s & %s & %s & \textbf{%s} %s \\"
                     % (grp, label, fmt(val), tag, TAGDESC.get(tag, "")))
            first = False
            n += 1
        L.append(r"\midrule")
    if L[-1] == r"\midrule":
        L.pop()
    L.append(r"\bottomrule")
    L.append(r"\end{tabular}")
    L.append(r"\end{table*}")

    io.open(OUT, "w", encoding="utf-8").write("\n".join(L) + "\n")
    print("wrote %s (%d parameters)" % (OUT, n))

    # provenance census, for the paper's honesty statement
    census = {}
    for sec in tags:
        for key, (_, tag) in tags[sec].items():
            if key in SKIP or not tag:
                continue
            census[tag] = census.get(tag, 0) + 1
    print("provenance census:", dict(sorted(census.items())))
    tot = sum(census.values())
    print("assumptions: %d of %d parameters (%.0f%%)"
          % (census.get("ASM", 0), tot, 100.0 * census.get("ASM", 0) / tot))
    print("engineering: %d of %d parameters" % (census.get("ENG", 0), tot))
    print("literature: %d of %d parameters" % (census.get("LIT", 0), tot))


if __name__ == "__main__":
    main()
