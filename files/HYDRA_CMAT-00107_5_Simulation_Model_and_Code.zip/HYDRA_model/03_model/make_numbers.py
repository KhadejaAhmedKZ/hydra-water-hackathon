"""
make_numbers.py — Emits 04_paper/numbers.tex from the results files.

WHY THIS EXISTS
Twice during development the manuscript carried numbers that no longer matched
the results directory: once because an experiment was re-run after the text was
written, and once because a metric definition changed. Both were caught only by
audit. Hand-transcribing numbers from CSVs into LaTeX is the root cause.

This script removes the transcription step. Every load-bearing number in the
manuscript is defined here as a LaTeX macro read straight from results/*.csv,
so the text cannot drift from the data: re-run the experiments, re-run this,
and the paper is correct by construction.

Usage:  python make_numbers.py      (after run_experiments.py)
"""

import io
import json
import os

import numpy as np
import pandas as pd

import config as C
import physics as P
import fouling as F

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
OUT = os.path.abspath(os.path.join(HERE, "..", "04_paper", "numbers.tex"))

macros = []
missing = []


def put(name, value, fmt="%.3f"):
    """Define a LaTeX macro. Name must be letters only (TeX restriction)."""
    if value is None or (isinstance(value, float) and not np.isfinite(value)):
        macros.append((name, r"\textcolor{red}{??}"))
        missing.append(name)
        return
    macros.append((name, fmt % value if isinstance(value, float) else str(value)))


def load(fn):
    p = os.path.join(RES, fn)
    if not os.path.exists(p):
        return None
    return pd.read_csv(p)


# ===========================================================================
# Calibration (recomputed, not read -- these are deterministic)
# ===========================================================================
put("calPiOcean", float(P.osmotic_pressure_bar(35.0, 25.0)), "%.2f")
put("calPiGulf", float(P.osmotic_pressure_bar(45.0, 35.0)), "%.2f")
put("calSecOcean", float(P.sec_process_kWh_m3(35.0, 25.0, 0.45, 0.0)), "%.2f")
put("calSecGulfSummer", float(P.sec_process_kWh_m3(45.0, 35.0, 0.40, 0.0)), "%.2f")
put("calSecTotalGulf", float(P.sec_total_kWh_m3(45.0, 30.0, 0.40, 0.0, 1.0)), "%.2f")
put("calPfeedGulf", float(P.required_feed_pressure_bar(45.0, 35.0, 0.40, 0.0)), "%.1f")
put("calTcfCold", float(P.tcf(20.0)), "%.3f")
put("calTcfHot", float(P.tcf(35.0)), "%.3f")
_oc = float(P.sec_process_kWh_m3(35.0, 25.0, 0.45, 0.0))
_gu = float(P.sec_process_kWh_m3(45.0, 35.0, 0.40, 0.0))
put("calGulfPenaltyPct", 100.0 * (_gu / _oc - 1.0), "%.1f")
_, _Rrep, _ = F.degradation_shadow_price()
put("calRstar", float(_Rrep), "%.4f")
put("cfgDemand", float(C.DEMAND_M3_DAY), "%.0f")
put("cfgNtolDefault", float(_Rrep / (C.FOULING["dRf_per_restart"]
                                    * C.FOULING["irreversible_fraction_restart"])),
    "%.0f")

# ===========================================================================
# Resource data
# ===========================================================================
hp = os.path.join(HERE, "data", "taweelah_hourly_2023.csv")
ap = os.path.join(HERE, "data", "taweelah_aod_2023.csv")
if os.path.exists(hp):
    h = pd.read_csv(hp, index_col=0).head(8760)
    put("resGhi", float(h.ALLSKY_SFC_SW_DWN.sum() / 1000.0), "%.0f")
    put("resTairMin", float(h.T2M.min()), "%.1f")
    put("resTairMax", float(h.T2M.max()), "%.1f")
if os.path.exists(ap):
    a = pd.read_csv(ap, index_col=0)
    put("resAodMean", float(a.AOD_55.mean()), "%.3f")
    put("resAodPcNF", float(a.AOD_55.quantile(0.95)), "%.2f")   # p95
    put("resAodMax", float(a.AOD_55.max()), "%.2f")

# ===========================================================================
# E1 seasonal
# ===========================================================================
e1 = load("E1_seasonal.csv")
if e1 is not None:
    put("seasSecMin", float(e1.sec_kWh_m3.min()), "%.3f")
    put("seasSecMax", float(e1.sec_kWh_m3.max()), "%.3f")
    put("seasSecMinDoy", int(e1.loc[e1.sec_kWh_m3.idxmin(), "doy"]))
    put("seasSecMaxDoy", int(e1.loc[e1.sec_kWh_m3.idxmax(), "doy"]))
    put("seasSecMinT", float(e1.loc[e1.sec_kWh_m3.idxmin(), "T_sea_C"]), "%.1f")
    put("seasSecMaxT", float(e1.loc[e1.sec_kWh_m3.idxmax(), "T_sea_C"]), "%.1f")
    put("seasFoulRatio", float(e1.foul_rate_op.max() / e1.foul_rate_op.min()), "%.2f")
    put("seasFoulMin", float(e1.foul_rate_op.min()), "%.2e")
    put("seasFoulMax", float(e1.foul_rate_op.max()), "%.2e")
else:
    missing.append("E1_seasonal.csv")

# ===========================================================================
# E2 policy comparison (flex-enabled design)
# ===========================================================================
NAME = {"baseload_grid": "Gb", "pv_baseload": "Pb",
        "flex_blind": "Fb", "flex_aware": "Fa"}
e2 = load("E2_policies.csv")
if e2 is not None:
    fx = e2[e2.design == "flex-enabled"].drop_duplicates("policy").set_index("policy")
    for pol, tag in NAME.items():
        if pol not in fx.index:
            missing.append("E2:" + pol)
            continue
        r = fx.loc[pol]
        put("pol%sLcow" % tag, float(r.lcow_usd_m3), "%.3f")
        put("pol%sRe" % tag, 100 * float(r.re_fraction), "%.1f")
        put("pol%sLife" % tag, float(r.membrane_life_yr), "%.2f")
        put("pol%sRestarts" % tag, int(round(float(r.n_restart_per_yr))))
        put("pol%sMemCost" % tag, float(r.cost_membrane), "%.3f")
        put("pol%sElecCost" % tag, float(r.cost_elec), "%.3f")
        put("pol%sCapCost" % tag, float(r.cost_capital), "%.3f")
        put("pol%sFixedCost" % tag, float(r.cost_fixed), "%.3f")
        put("pol%sCipCost" % tag, float(r.cost_cip), "%.3f")
        put("pol%sPvClean" % tag, float(r.cost_pv_clean), "%.3f")
        put("pol%sCf" % tag, float(r.capacity_factor), "%.2f")
        put("pol%sSec" % tag, float(r.sec_mean_kWh_m3), "%.2f")
        put("pol%sCip" % tag, float(r.n_cip_per_yr), "%.1f")
    if "pv_baseload" in fx.index and "flex_blind" in fx.index:
        b, bl, aw = fx.loc["pv_baseload"], fx.loc["flex_blind"], fx.loc["flex_aware"]
        put("blindLcowRisePct",
            100.0 * (float(bl.lcow_usd_m3) / float(b.lcow_usd_m3) - 1.0), "%.0f")
        put("blindEnergySaving",
            float(b.cost_elec) - float(bl.cost_elec), "%.3f")
        put("blindMemExtra",
            float(bl.cost_membrane) - float(b.cost_membrane), "%.3f")
        put("blindPenaltyRef",
            float(bl.lcow_usd_m3) - float(aw.lcow_usd_m3), "%.3f")
        _sav = float(b.cost_elec) - float(bl.cost_elec)
        _ext = float(bl.cost_membrane) - float(b.cost_membrane)
        put("blindRatio", (_ext / _sav) if _sav > 0 else None, "%.0f")
        put("polFbReGain",
            100 * (float(bl.re_fraction) - float(b.re_fraction)), "%.1f")
else:
    missing.append("E2_policies.csv")

# ===========================================================================
# E4 cycle-tolerance frontier
# ===========================================================================
e4 = load("E4_cycle_frontier.csv")
if e4 is not None:
    e4 = e4.copy()
    e4["N_tol"] = pd.to_numeric(e4.N_tol, errors="coerce")
    fin = e4[np.isfinite(e4.N_tol)]
    base = fin[fin.label == "pv_baseload"].set_index("N_tol").lcow_usd_m3.sort_index()
    bl = fin[fin.label == "flex_blind"].set_index("N_tol").lcow_usd_m3.sort_index()
    aw = fin[fin.label == "flex_aware"].set_index("N_tol").lcow_usd_m3.sort_index()
    pen = (bl - base).dropna()
    ben = (aw - base).dropna()
    put("frontMaxPenalty", float(pen.max()), "%.3f")
    put("frontMaxBenefit", float(ben.min()), "%.3f")
    put("frontMaxPenaltyPct", 100.0 * float(pen.max() / base.reindex(pen.index).iloc[
        int(np.argmax(pen.to_numpy()))]), "%.0f")
    put("frontMaxBenefitPct", 100.0 * abs(float(ben.min() / base.reindex(ben.index).iloc[
        int(np.argmin(ben.to_numpy()))])), "%.1f")
    if ben.min() != 0:
        put("frontAsymmetry", float(pen.max() / abs(ben.min())), "%.0f")
    else:
        put("frontAsymmetry", None)

    # log-interpolated crossover of the aware benefit through zero
    nv, dv = ben.index.to_numpy(float), ben.to_numpy(float)
    cross = None
    for i in range(len(dv) - 1):
        if dv[i] > 0 >= dv[i + 1]:
            f = dv[i] / (dv[i] - dv[i + 1])
            cross = 10 ** (np.log10(nv[i]) + f * (np.log10(nv[i + 1]) - np.log10(nv[i])))
            break
    put("frontNtolCrit", cross, "%.0f")
    put("frontNtolCritYears", (cross / 360.0) if cross else None, "%.1f")
    # frontier table rows
    # TeX command names may contain letters only, so cycle counts are mapped
    # to letter tags rather than embedded as digits.
    TAGS = {250: "Na", 500: "Nb", 1000: "Nc", 2000: "Nd", 4000: "Ne",
            8000: "Nf"}
    for nt, tag in TAGS.items():
        put("front%sYears" % tag, nt / 360.0, "%.1f")
        put("front%sBase" % tag, float(base.get(nt, np.nan)), "%.3f")
        put("front%sBlind" % tag, float(bl.get(nt, np.nan)), "%.3f")
        put("front%sAware" % tag, float(aw.get(nt, np.nan)), "%.3f")
        put("front%sDelta" % tag, float(ben.get(nt, np.nan)), "%.3f")
else:
    missing.append("E4_cycle_frontier.csv")

# ===========================================================================
# E3 saturation + implicit carbon price
# ===========================================================================
e3 = load("E3_design_space.csv")
if e3 is not None:
    s = e3[(e3.policy == "pv_baseload") & (e3.ro_oversize == 1.09)
           & (e3.unmet_frac < 0.02)].sort_values("pv_frac_parity")
    b0 = s[s.pv_frac_parity == 0.0]
    LBL = {0.0: "Zero", 0.3: "Low", 0.6: "Mid", 1.0: "Parity"}
    for pf, tag in LBL.items():
        t = s[np.isclose(s.pv_frac_parity, pf)]
        if t.empty:
            missing.append("E3:pv=%.1f" % pf)
            continue
        r = t.iloc[0]
        put("sat%sRe" % tag, 100 * float(r.re_fraction), "%.1f")
        put("sat%sLcow" % tag, float(r.lcow_usd_m3), "%.3f")
        put("sat%sPvMw" % tag, float(r.pv_kWp) / 1000.0, "%.1f")
        if not b0.empty and pf > 0:
            bb = b0.iloc[0]
            dl = float(r.lcow_usd_m3) - float(bb.lcow_usd_m3)
            dco2 = (float(bb.co2_t_yr) - float(r.co2_t_yr)) / float(r.ann_delivered_m3)
            put("sat%sDeltaLcow" % tag, dl, "%.3f")
            put("sat%sCarbon" % tag, (dl / dco2) if dco2 > 0 else None, "%.0f")
    # marginal cost of the last PV doubling, quoted in the saturation section
    tm = s[np.isclose(s.pv_frac_parity, 0.6)]
    tp = s[np.isclose(s.pv_frac_parity, 1.0)]
    if not tm.empty and not tp.empty:
        put("satLastDoubleCost",
            float(tp.iloc[0].lcow_usd_m3) - float(tm.iloc[0].lcow_usd_m3), "%.3f")
        put("satLastDoubleRe",
            100 * (float(tp.iloc[0].re_fraction) - float(tm.iloc[0].re_fraction)),
            "%.1f")

    ok = e3[e3.unmet_frac < 0.02]
    bst = ok.loc[ok.lcow_usd_m3.idxmin()]
    put("optPvFrac", float(bst.pv_frac_parity), "%.2f")
    put("optOversize", float(bst.ro_oversize), "%.2f")
    put("optLcow", float(bst.lcow_usd_m3), "%.3f")
else:
    missing.append("E3_design_space.csv")

# ===========================================================================
# E7 free design choice
# ===========================================================================
_p7 = os.path.join(RES, "E7_cost_of_blindness.json")
if os.path.exists(_p7):
    j = json.load(io.open(_p7, encoding="utf-8"))
    put("blindApparent", float(j["blind_apparent"]), "%.3f")
    put("blindActual", float(j["blind_actual"]), "%.3f")
    put("blindSelfErrorPct",
        100.0 * (float(j["blind_actual"]) / float(j["blind_apparent"]) - 1.0), "%.1f")
    put("freeChoicePenalty", float(j["penalty_usd_m3"]), "%.3f")
    put("freeChoiceAwareLcow", float(j["aware_lcow"]), "%.3f")
    put("freeChoiceBaseLcow", float(j["baseload_lcow"]), "%.3f")
else:
    missing.append("E7_cost_of_blindness.json")

# ===========================================================================
# E5 / E6 frontier extents
# ===========================================================================
e5 = load("E5_frontier_2d.csv")
if e5 is not None:
    e5 = e5.copy()
    e5["N_tol"] = pd.to_numeric(e5.N_tol, errors="coerce")
    put("bioMin", float(e5.biofouling_index.min()), "%.1f")
    put("bioMax", float(e5.biofouling_index.max()), "%.1f")
    put("bioBenefitLow", float(e5[np.isclose(e5.biofouling_index,
                                             e5.biofouling_index.min())]
                               .delta_lcow.min()), "%.3f")
    put("bioBenefitHigh", float(e5[np.isclose(e5.biofouling_index,
                                              e5.biofouling_index.max())]
                                .delta_lcow.min()), "%.3f")
else:
    missing.append("E5_frontier_2d.csv")

e6 = load("E6_tariff_frontier.csv")
if e6 is not None:
    e6 = e6.copy()
    e6["N_tol"] = pd.to_numeric(e6.N_tol, errors="coerce")
    lo = e6[e6.N_tol <= 1000]
    put("tariffMaxSpread", float(e6.tariff_spread.max()), "%.2f")
    put("tariffLowNtolMinDelta", float(lo.delta_lcow.min()) if not lo.empty else None,
        "%.3f")
    put("tariffLowNtolAllPositive",
        "yes" if (not lo.empty and (lo.delta_lcow > -1e-9).all()) else "no")

    # the worked example quoted in the text: N_tol = 500, spread 0 vs max
    nb = e6[np.isclose(e6.N_tol, 500.0)]
    if not nb.empty:
        lo_s = nb.loc[nb.tariff_spread.idxmin()]
        hi_s = nb.loc[nb.tariff_spread.idxmax()]
        put("tariffNbFlat", float(lo_s.delta_lcow), "%.3f")
        put("tariffNbWide", float(hi_s.delta_lcow), "%.3f")
    # the infinite-tolerance row, where spread behaves as expected
    inf = e6[~np.isfinite(e6.N_tol)]
    if not inf.empty:
        put("tariffInfFlat", float(inf.loc[inf.tariff_spread.idxmin()].delta_lcow),
            "%.3f")
        put("tariffInfWide", float(inf.loc[inf.tariff_spread.idxmax()].delta_lcow),
            "%.3f")
else:
    missing.append("E6_tariff_frontier.csv")

# ===========================================================================
# E8 sensitivity ranking
# ===========================================================================
e8 = load("E8_sensitivity.csv")
if e8 is not None:
    d = e8[e8.label == "pv_baseload"]
    spans = []
    for p, g in d.groupby("param"):
        spans.append((p, float(g.lcow_usd_m3.max() - g.lcow_usd_m3.min())))
    spans.sort(key=lambda x: -x[1])
    PRETTY = {
        "FOULING.alpha_shear": "shear-removal exponent",
        "FOULING.idle_multiplier": "stagnation multiplier",
        "FOULING.dRf_per_restart": "per-restart increment",
        "SEAWATER.biofouling_index": "feed biofouling index",
        "SEAWATER.salinity_g_L": "feed salinity",
        "ECON.elec_price_usd_kWh": "electricity price",
        "ECON.pv_capex_usd_kWp": "PV capital cost",
        "ECON.batt_capex_usd_kWh": "battery capital cost",
    }
    for i, (p, sp) in enumerate(spans[:3], start=1):
        nm = {1: "One", 2: "Two", 3: "Three"}[i]
        macros.append(("sens%sName" % nm, PRETTY.get(p, p.replace("_", " "))))
        put("sens%sSpan" % nm, sp, "%.3f")
    put("sensCount", len(spans))
else:
    missing.append("E8_sensitivity.csv")

# ===========================================================================
# Parameter census
# ===========================================================================
import subprocess
import re as _re
try:
    out = subprocess.check_output(["python", "make_param_table.py"], cwd=HERE,
                                  stderr=subprocess.STDOUT).decode()
    m = _re.search(r"assumptions:\s*(\d+)\s*of\s*(\d+)", out)
    if m:
        put("paramAsm", int(m.group(1)))
        put("paramTotal", int(m.group(2)))
        put("paramAsmPct", 100.0 * int(m.group(1)) / int(m.group(2)), "%.0f")
    _m2 = _re.search(r"engineering:\s*(\d+)", out)
    if _m2:
        put("paramEng", int(_m2.group(1)))
    _m3 = _re.search(r"literature:\s*(\d+)", out)
    if _m3:
        put("paramLit", int(_m3.group(1)))
except Exception:                                             # noqa: BLE001
    missing.append("parameter census")


# ===========================================================================
# ===========================================================================
# Verification-pass additions
# ===========================================================================
import math as _math

# Thermodynamic floor computed from the paper's own Eqs. (1) and (5). This
# replaces an externally quoted figure that could not be confirmed.
_S, _T, _r = 35.0, 25.0, 0.5
_pif = float(P.osmotic_pressure_bar(_S, _T))
_pic = float(P.osmotic_pressure_bar(P.concentrate_salinity(_S, _r), _T))
put("thermoLeastWork", _pif * _math.log(1.0 / (1.0 - _r)) / _r * P.BAR_M3_TO_KWH, "%.2f")
put("thermoSingleStage", _pic * P.BAR_M3_TO_KWH, "%.2f")

# Energy and capital shares from the model's own cost decomposition
# (conventional design, grid baseload), replacing uncited vendor percentages.
if e2 is not None:
    _g = e2[(e2.design == "conventional") & (e2.policy == "baseload_grid")]
    if not _g.empty:
        _g = _g.iloc[0]
        put("costElecShareLcow", 100.0 * float(_g.cost_elec) / float(_g.lcow_usd_m3), "%.0f")
        put("costCapShareLcow", 100.0 * float(_g.cost_capital) / float(_g.lcow_usd_m3), "%.0f")

# Al Taweelah: published figures are CAPACITY shares. The energy share below is
# a model estimate from the simulated PV specific yield (with soiling).
try:
    import simulate as _Smod
    _rs = _Smod.load_resource()
    _yield = float(P.pv_output_kW(_rs["ghi"], _rs["tair"], 1.0,
                                  _rs["soiling"], _rs["wind"]).sum())
    _pvmw = float(C.SITE["pv_installed_MWp"])
    _sec = 3.9
    if e2 is not None:
        _pb = e2[(e2.design == "conventional") & (e2.policy == "pv_baseload")]
        if not _pb.empty:
            _sec = float(_pb.iloc[0].sec_mean_kWh_m3)
    _share = _pvmw * 1000.0 * _yield / (C.SITE["capacity_m3_day"] * _sec * 365.0)
    put("tawPvMw", _pvmw, "%.0f")
    put("tawEnergySharePct", 100.0 * _share, "%.0f")
    put("resPvYield", _yield, "%.0f")
except Exception as _exc:                                      # noqa: BLE001
    missing.append("Taweelah energy share (%s)" % _exc)

# Grid emission factor range (Climate Action Tracker, Nov 2024). LCOW does not
# depend on the factor and avoided CO2 is proportional to it, so the
# break-even carbon price scales exactly as EF_model / EF.
_EF0 = float(C.ECON["grid_co2_kg_kWh"])
_EF_HI, _EF_LO = 0.55, 0.27
put("gridEfModel", _EF0, "%.2f")
put("gridEfHigh", _EF_HI, "%.2f")
put("gridEfLow", _EF_LO, "%.2f")
if e3 is not None:
    _s3 = e3[(e3.policy == "pv_baseload") & (e3.ro_oversize == 1.09)
             & (e3.unmet_frac < 0.02)].sort_values("pv_frac_parity")
    _b3 = _s3[_s3.pv_frac_parity == 0.0]
    if not _b3.empty:
        _b3 = _b3.iloc[0]
        for _pf, _tag in ((0.3, "Low"), (0.6, "Mid"), (1.0, "Parity")):
            _t3 = _s3[np.isclose(_s3.pv_frac_parity, _pf)]
            if _t3.empty:
                continue
            _t3 = _t3.iloc[0]
            _dl = float(_t3.lcow_usd_m3) - float(_b3.lcow_usd_m3)
            _dc = (float(_b3.co2_t_yr) - float(_t3.co2_t_yr)) / float(_t3.ann_delivered_m3)
            if _dc > 0:
                _p3 = _dl / _dc
                put("sat%sCarbonDirty" % _tag, _p3 * _EF0 / _EF_HI, "%.0f")
                put("sat%sCarbonClean" % _tag, _p3 * _EF0 / _EF_LO, "%.0f")

# Sensitivity of process SEC to recovery over the 31-34% reported for stable
# high-salinity, high-temperature operation (Kim et al., 2020), vs base case.
_Tm = float(C.SEAWATER["sst_mean_C"])
_Sd = float(C.SEAWATER["salinity_g_L"])
_base = float(P.sec_process_kWh_m3(_Sd, _Tm, C.RO["recovery"], 0.0))
_dmax = max(abs(float(P.sec_process_kWh_m3(_Sd, _Tm, _rr, 0.0)) - _base)
            for _rr in (0.31, 0.34))
put("secRecoveryDelta", _math.ceil(_dmax * 100.0) / 100.0, "%.2f")


def main():
    lines = [
        r"% AUTO-GENERATED by 03_model/make_numbers.py -- DO NOT EDIT.",
        r"% Every macro below is read from 03_model/results/*.csv so that the",
        r"% manuscript cannot drift from the data. Re-run run_experiments.py",
        r"% then make_numbers.py after any model change.",
        r"%",
        r"% A macro rendering as a red '??' means its source file was missing.",
        "",
    ]
    for name, val in macros:
        lines.append(r"\newcommand{\%s}{%s}" % (name, val))
    io.open(OUT, "w", encoding="utf-8").write("\n".join(lines) + "\n")

    print("wrote %s" % OUT)
    print("  %d macros defined" % len(macros))
    if missing:
        print("  %d MISSING/unresolved:" % len(missing))
        for m in sorted(set(missing)):
            print("     %s" % m)
    else:
        print("  all macros resolved")


if __name__ == "__main__":
    main()
