# Literature Matrix — Low-Energy & Renewable-Powered Desalination (2023–2026)

Team HYDRA · KU–UN Global Water Hackathon 2026 · Theme 1
Compiled 2026-09-12.

**STATUS legend**
- `[V]` = retrieved and read directly; authors and numbers confirmed.
- `[S]` = found via search, abstract-level confirmed, **full bibliographic details TO VERIFY before submission**.

Nothing in this file is invented. Every `[S]` row must be opened and confirmed before it enters the paper's reference list.

> **VERIFICATION PASS 2026-09-13.** Every source the paper cites was checked against
> CrossRef and, where a number is quoted, against the abstract or full text. Rows marked
> ⚠ were corrected or removed. This matrix is kept as the historical search record;
> the authoritative audit trail is `VERIFICATION_LOG.md` and the `verification` fields in
> `04_paper/references.bib`.

---

## A. The energy-headroom question — does "cut RO energy" even have room?

| # | Source | Key figure | STATUS |
|---|---|---|---|
| A1 | "Practical minimum energy use of seawater reverse osmosis", *Joule* (2024). `cell.com/joule/fulltext/S2542-4351(24)00373-8` | 69% of excess energy above thermodynamic least work removable with state-of-the-art; 82% with future tech incl. batch RO | `[S]` paywalled (403) ⚠ VERIFIED 13 Sep: abstract available to us did not show the 69% / 82% figures; **removed from paper** |
| A2 | "Energy Consumption in Spiral-Wound SWRO at the Thermodynamic Limit", *Ind. Eng. Chem. Res.* doi:10.1021/ie404067s | Practical thermodynamic limit ≈1.6 kWh/m³ at 35 g/L, 50% recovery | `[S]` ⚠ VERIFIED 13 Sep: ≈1.6 kWh/m³ limit **not used**; paper computes least work and single-stage minimum from its own equations |
| A3 | "Global energy, costs, and emissions from RO desalination under future water scarcity", *Water Research* (2025). `S0043135425017282` | Global forward-looking energy / cost / emissions baseline | `[S]` |
| A4 | Multi-source consensus | Best large-scale plants today 2–3 kWh/m³ (process); >3 kWh/m³ plant-total incl. pre/post-treatment | `[S]` ⚠ VERIFIED 13 Sep: 2–3 kWh/m³ band **removed**; paper benchmarks against 1.794 kWh/m³ (Peñate-Suárez 2026) and 3.11–3.13 kWh/m³ (Kim & Hong 2023) |

> **Implication.** The RO process is already near its thermodynamic floor. A paper claiming large specific-energy reductions from the RO step alone is not credible. Remaining headroom lies in the energy **source**, in **system-level operation**, and in **displacing legacy thermal capacity**.

---

## B. Gulf-specific severity — why the UAE is not a generic case

| # | Source | Key figure | STATUS |
|---|---|---|---|
| B1 | "Pilot study of emerging low-energy SWRO desalination technologies for high-salinity, high-temperature, and high-turbidity seawater", *Desalination* (2023). `S0011916423005039` | States current SWRO **is not energy-efficient** for Arabian Gulf conditions | `[S]` **KEY JUSTIFIER** |
| B2 | "Characteristics of Desalination Brine and Its Impacts on Marine Chemistry and Health, With Emphasis on the Persian/Arabian Gulf: A Review", *Front. Mar. Sci.* (2022). doi:10.3389/fmars.2022.845113 | Gulf: semi-enclosed, mean depth ≈35 m, salinity ≈39–42 g/L | `[S]` |
| B3 | Gulf biofouling conditions (multi-source) | T frequently >35 °C; microbial counts 12,100–333,000 cells/mL; harmful algal blooms can force intake shutdown | `[S]` ⚠ VERIFIED 13 Sep: **no primary source located** for the cells/mL counts; removed. Paper cites Winters et al. 2022 (serious biofouling at a Gulf SWRO plant) |
| B4 | "An assessment of seawater desalination impact on salinities in the Arabian/Persian Gulf using a 3D circulation model" (2025). `S1463500325000071` | Basin-scale salinity accumulation from brine discharge | `[S]` |

---

## C. Flexibility and dispatch — the competing literature

| # | Source | Key figure | STATUS |
|---|---|---|---|
| **C1** | **Alahmed, Botterud, Amin & Al-Awami (2026), "Optimal Dispatch of Electricity and Water in Renewable-Integrated Desalination Plants", arXiv:2601.02243, 5 Jan 2026** | Threshold dispatch policy; three modes (import / net-zero / export); optimal joint dispatch \$119,180/day vs \$99,872 max-RO and \$112,850 passive-thermal benchmarks | **`[V]` READ IN FULL** |
| **C1-gaps** | **Alahmed et al. — their own stated future work** | (1) no energy storage; (2) *"simplified water-electricity conversion functions; in practice, energy-use depends on ambient conditions such as salinity and temperature"*; (3) short-run only, no capacity investment; (4) no joint planning–operation model. **Membrane fouling/degradation NOT modelled. No Gulf salinity or temperature.** | **`[V]` ← OUR GAP, IN THEIR OWN WORDS** |
| C2 | "Valuing energy flexibility from water systems", *Nature Water* (2024). doi:10.1038/s44221-024-00316-4 | Framework for valuing water-system energy flexibility | `[S]` |
| C3 | "Flexibility quantification of desalination plants for demand response: an adaptive robust optimization methodology", *Applied Energy* (2024). `S0306261924012182` | Robust flexibility quantification | `[S]` |
| C4 | "Analysis of variable reverse osmosis operation powered by solar energy", *Renewable Energy* (2023). `S0960148123002872` | **Variable operation cuts yearly cost 5–10% vs steady operation** | `[S]` **KEY BASELINE** ⚠ VERIFIED 13 Sep: **5–10% figure not found** in the abstract; removed. Verified: variable operation matches RO load to PV |
| C5 | "Can flexible operation of brackish desalination facilities reduce the cost of desalted water? A case study in Southern California", *Desalination* (2026). `S0011916426002535` | Brackish, US case; flexible-operation economics | `[S]` |
| C6 | "Stochastic Power-Water Coordination: Unlocking Flexibility in Hybrid RO Desalination Plants via Variable-Speed Pumps and Tank Mixing", arXiv:2601.07295 | Tank + variable-speed-pump flexibility | `[S]` |
| C7 | Load-shifting result (multi-source) | ≈10% cost decrease; supports higher variable-renewable penetration | `[S]` ⚠ VERIFIED 13 Sep: multi-source, no primary paper; **not used** |

---

## D. Fouling economics and the intermittency penalty — the other half of the gap

| # | Source | Key figure | STATUS |
|---|---|---|---|
| **D1** | "Fouling, performance and cost analysis of membrane-based water desalination technologies: a critical review", *J. Environ. Manage.* (2022). `S0301479721019848` | **Fouling ≈24% of OPEX**; dominant term = early membrane replacement, then additional energy, then cleaning | `[S]` **CRITICAL NUMBER** ⚠ VERIFIED 13 Sep: **24%-of-OPEX not confirmed**; removed. Cited only as a general fouling review |
| D2 | "Design of photovoltaic powered reverse osmosis desalination systems considering membrane fouling caused by intermittent operation", *Renewable Energy* (2019). `S0960148118313843` | Neglecting fouling in design → **under-sized systems**; fouling model essential for cost-optimal design | `[S]` **CLOSEST PRIOR ART** |
| D3 | "Impact of intermittent operation on reverse osmosis membrane fouling for brackish groundwater desalination systems", *J. Membrane Sci.* (2019). `S0376738818332447` | **No significant fouling change** — but on surrogate **brackish** water with **minimal biological content** | `[S]` **SCOPE LIMIT = our opening** ⚠ VERIFIED 13 Sep: **WRONG as summarised**: with rinse + antiscalant permeability stays >70%, without rinse it falls <50% — a penalty, not 'no change'. Corrected in paper |
| D4 | 14-year intermittently-operated RO plant record | Daily shutdown/start-up caused no additional problems (brackish) | `[S]` ⚠ VERIFIED 13 Sep: **corrected**: about half of water permeability lost over 14 years, SEC 1.82→2.21 kWh/m³ (Ruiz-García & Nuez 2020, brackish) |
| D5 | Mitigation strategies | Permeate rinse before shutdown reduces permeability decline; battery smoothing minimises fouling | `[S]` |

> **Implication.** Every "intermittency is fine" result is on **low-biology brackish** water. The Arabian Gulf is the global worst case for biofouling. Transferability of D3/D4 to Gulf SWRO is **unestablished** — a real, defensible gap.

---

## E. Renewable + storage techno-economics — crowded, must not duplicate

| # | Source | Key figure | STATUS |
|---|---|---|---|
| E1 | "Techno-economic evaluation of solar photovoltaic-powered reverse osmosis desalination for different locations in Saudi Arabia", *Desalination* (2024). `S0011916424011640` | Location-resolved LCOW, KSA | `[S]` |
| E2 | "Battery versus hydrogen storage for renewable-powered RO desalination: a technoeconomic and environmental analysis in coastal Saudi Arabia", *Int. J. Hydrogen Energy* (2025). `S0360319925054692` | Battery LCOW 1.66 \$/m³; hydrogen up to 2.55 \$/m³ | `[S]` ⚠ VERIFIED 13 Sep: 1.66 / 2.55 USD/m³ **not confirmed** in abstract; removed |
| E3 | "Comparative assessment of battery and pumped hydro storage for renewable-powered reverse osmosis desalination in Saudi Arabia", *J. Energy Storage* (2025). `S2352152X25045220` | Battery vs pumped hydro | `[S]` |
| E4 | "Solar-Powered SWRO Desalination in Jubail: A Comparative Techno-Economic Analysis of PV and CSP Using SAM", *Jordan J. Electrical Eng.* 12(2) | PV LCOW 0.82 USD/m³, beats CSP; 25-yr life, 5.5% real discount rate, 2.14 USD/m³ tariff | `[S]` |
| E5 | Gomaa et al. (2025), "Seawater Reverse Osmosis Desalination-Based Renewable Energy: Classifications, Challenges, Methods of Driving, and Future Prospects", *Int. J. Energy Research*. doi:10.1155/er/5544777 | Review; challenges include storage need and supply volatility | `[S]` 403 on fetch; open access — retry |
| E6 | "Review of solar-powered reverse osmosis desalination systems: structure, performance, and efficiency", *Water Sci. Technol.* (2025). doi:10.2166/wst.2025.141 | Review | `[S]` |
| E7 | "The Synergy of Renewable Energy and Desalination: An Overview of Current Practices and Future Directions", *Applied Sciences* 15(4):1794 (2025) | Review | `[S]` |

> **Implication.** A plain "techno-economic assessment of solar RO in the Gulf" has **already been done at least four times in 2024–2025**. A duplicate would be rejected. We must add a mechanism these papers omit.

---

## F. Process intensification (batch / CCRO) — relevant but brackish-biased

| # | Source | Key figure | STATUS |
|---|---|---|---|
| F1 | "Energy efficiency of batch and semi-batch (CCRO) reverse osmosis desalination", *Water Research* (2016). `S0043135416307072`, PMID 27728821 | CCRO up to **37%**, batch RO up to **64%** savings vs continuous — at **high recovery, brackish** | `[S]` |
| F2 | "Parameters influencing semi-batch reverse osmosis — model based analysis", *Desalination* (2025). `S0011916425000244` | Feed ratio, plug-flow/closed-loop recovery, recirculation rate; pilot-scale CLRO | `[S]` |
| F3 | Multi-source | SWRO SEC 2.0–5.5 kWh/m³; time-varying/semi-batch offers further reduction | `[S]` |

---

## G. UAE and national context — for the UAE Water Impact Award

| # | Source | Key figure | STATUS |
|---|---|---|---|
| **G1** | **Nwafor, Nwafor, Zakaria & Nwankwo (2025), "A Feed-Forward Artificial Intelligence Pipeline for Sustainable Desalination under Climate Uncertainties: UAE Insights", arXiv:2507.10609** | UAE: desalination supplies **>90% of drinking water**, consumes **≈15% of national electricity**, contributes **>22% of energy-related CO₂**. Two-stage AOD→efficiency model, 98% accuracy, SHAP explainability, dust-aware rule-based control, packaged as an **interactive dashboard decision-support system** | **`[V]` READ IN FULL** |
| **G1-nums** | Cost anchors from G1 | PV cleaning ≈\$0.35/m²/session; membrane replacement up to \$200k/yr/plant; UAE electricity \$0.03–0.05/kWh; dust-event energy penalty up to 4 kWh/m² for a 10 MW solar facility | **`[V]`** |
| G2 | Al Taweelah IWP (ACWA Power / EWEC), Abu Dhabi | World's largest SWRO: 200 MIGD = 909,200 m³/day; **68 MWp PV**; solar to meet **30% of electricity in first 8 years, target 55%** by end of first quarter-life; commissioned 2022 | `[S]` industry sources ⚠ VERIFIED 13 Sep: **verified**: ≈69 MWp (pv magazine); solar ≥30% of the plant's electricity *capacity* (ACWA/EWEC), target 55%. Paper reconciles this with a ≈9% *energy* share |
| G3 | RO vs thermal | RO claimed ≈96% more energy-efficient than thermal desalination, >85% lower CO₂ | `[S]` **vendor/industry claim — verify, likely overstated** |
| G4 | Global market | SWRO ≈69% of installed desalination capacity; recovery 35–45%; global capacity growing ≈5.6%/yr 2024–2030 to ≈82 Mm³/day by 2030 | `[S]` |

---

## H. Brine valorisation — optional secondary contribution

| # | Source | Key figure | STATUS |
|---|---|---|---|
| H1 | "Unlocking the potential of desalinization brine: challenges and opportunities for the circular economy", *Resour. Conserv. Recycl.* (2025). `S0921344925001879` | Circular-economy framing | `[S]` |
| H2 | "Sustainable Desalination through Brine Mining: Turning an Environmental Challenge into an Economic Opportunity", *Water Resources Management* (2026). doi:10.1007/s11269-026-04740-x | Brine-mining economics | `[S]` |
| H3 | Brine revenue claim | Mineral-sales revenue reported >16× water-sales revenue in one system-level claim, implying "zero-cost" water | `[S]` **treat sceptically — best-case** |
| H4 | Maturity | Most brine-mining routes at pilot/early-commercial scale, especially lithium. Saudi Water Authority operates a Mg-from-brine facility, but for drinking-water Mg supplementation rather than industrial supply | `[S]` |

---

## Key premise corrections for Team HYDRA

1. **"Electricity is half the bill" is overstated.** Energy is **35–50% of OPEX**, but OPEX is only part of levelized cost — CAPEX amortisation is 30–40% of lifecycle cost. Energy is therefore roughly **20–30% of levelized water cost**, not half. (Labour 15–25% of OPEX; membranes 5–10%; chemicals 5–15%; maintenance 10–15%.)
2. **RO sits near its thermodynamic floor.** Large specific-energy cuts from the RO step itself are not available.
3. **Renewable-powered desalination is already commercial in Abu Dhabi.** Al Taweelah runs 68 MWp of PV today. Proposing it as a novel idea is not defensible. The open question is **why its solar share is capped at 30–55% and how to raise it.**
4. **Plain solar-RO techno-economic assessment is saturated** (≥4 Gulf/KSA papers in 2024–2025).
5. **The unclaimed gap:** no study couples **Gulf-parameterised biofouling and membrane-degradation dynamics** to **renewable dispatch and storage co-optimisation**. The newest dispatch paper in the field (C1) names precisely this as its own limitation.
